#include <QtTest>
#include "gamestate.hh"

// add necessary includes here

class gamestatetest : public QObject
{
    Q_OBJECT

public:
    gamestatetest();
    ~gamestatetest();

private slots:
    void init();
    void player();
    void gamephase();

private:
    std::shared_ptr<GameState> gamestate_;

};

gamestatetest::gamestatetest()
{
    gamestate_ = std::make_shared<GameState>();
}

gamestatetest::~gamestatetest()
{

}

void gamestatetest::init()
{
}

void gamestatetest::player()
{
    for(auto i = 0; i < 10; ++i){
        gamestate_->changePlayerTurn(i);
        QVERIFY(gamestate_->currentPlayer() == i);
    }
}

void gamestatetest::gamephase()
{
    gamestate_->changeGamePhase(Common::MOVEMENT);
    QVERIFY(gamestate_->currentGamePhase() == Common::MOVEMENT);
    gamestate_->changeGamePhase(Common::SINKING);
    QVERIFY(gamestate_->currentGamePhase() == Common::SINKING);
    gamestate_->changeGamePhase(Common::SPINNING);
    QVERIFY(gamestate_->currentGamePhase() == Common::SPINNING);
}

QTEST_APPLESS_MAIN(gamestatetest)

#include "tst_gamestatetest.moc"
