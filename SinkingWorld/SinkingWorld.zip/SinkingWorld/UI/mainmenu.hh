#ifndef MAINMENU_HH
#define MAINMENU_HH

#include "buttonmainmenu.hh"
#include "settingsdialog.hh"

#include <QGraphicsView>

#include <QGraphicsPixmapItem>
#include <QGraphicsTextItem>
#include <QMouseEvent>
#include <memory>
#include <string>

/* Impelents a mainmenu scene for the game.
 * In mainmenu you can adjust the settings and read help for playing the game.
 */


class GameBoard;
class MainMenu : public QGraphicsScene
{

public:
    MainMenu(GameBoard* gameBoard);
    ~MainMenu();

    // Functionality for buttons:
    void newgame();
    void settings();
    void highscore();
    void highscoreClose();
    void help();
    void helpClose();
    void info();
    void infoClose();

    //Settings
    int playerCount = 1;
    int difficulty = 1;
    std::string player1 = "Player 1";
    std::string player2 = "Player 2";
    std::string player3 = "Player 3";
    std::string player4 = "Player 4";

    std::vector<std::string> playerNames;

private:
    GameBoard* gameBoard_;

    //Buttons:
    ButtonMainMenu* header_;
    ButtonMainMenu* newgameButton_;
    ButtonMainMenu* settingsButton_;
    ButtonMainMenu* highscoreButton_;
    ButtonMainMenu* closeHighscoreButton_;
    ButtonMainMenu* helpButton_;
    ButtonMainMenu* closeHelpButton_;
    ButtonMainMenu* infoButton_;
    ButtonMainMenu* closeInfoButton_;

    //Texts
    QGraphicsTextItem* infoText_;
    QGraphicsTextItem* helpText_;
    QGraphicsTextItem* highscoresText_;
    QGraphicsTextItem* headline_;




    void createAssets();
    void releaseAssets();
    void showMenuButtons();
    void hideMenuButtons();

};

#endif // MAINMENU_HH
