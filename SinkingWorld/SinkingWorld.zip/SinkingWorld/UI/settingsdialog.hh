#ifndef SETTINGSDIALOG_HH
#define SETTINGSDIALOG_HH

#include <QDialog>
#include <QFormLayout>
#include <QGridLayout>
#include <QPushButton>
#include <QSpinBox>
#include <QLineEdit>
#include <string>

/* Impelents QDialog for adjusting the settings in mainmenu.
 */


class SettingsDialog:public QDialog
{
    Q_OBJECT
public:
    SettingsDialog(int playercount = 1,
                   std::string player1 = "", std::string player2 = "",
                   std::string player3 = "", std::string player4 = "");

    ~SettingsDialog();

    int getPlayerCount();
    int getDifficulty();
    std::string getPlayer1Name();
    std::string getPlayer2Name();
    std::string getPlayer3Name();
    std::string getPlayer4Name();

    //settings
    //Settings
    int players;
    QString namePlayer1;
    QString namePlayer2;
    QString namePlayer3;
    QString namePlayer4;

public slots:
    void okButtonPress();
    void playerCountChanged();
    void player1NameChanged();
    void player2NameChanged();
    void player3NameChanged();
    void player4NameChanged();

private:
    void setupLayout();

    QFormLayout* formLayout_;
    QGridLayout* gridLayout_;

    QPushButton* okButton_;

    QSpinBox* playersSpinBox_;

    QLineEdit* player1NameLineEdit_;
    QLineEdit* player2NameLineEdit_;
    QLineEdit* player3NameLineEdit_;
    QLineEdit* player4NameLineEdit_;
    void releaseAssets();

};

#endif // SETTINGSDIALOG_HH
