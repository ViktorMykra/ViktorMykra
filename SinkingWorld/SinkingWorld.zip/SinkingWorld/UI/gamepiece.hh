#ifndef GAMEPIECE_HH
#define GAMEPIECE_HH

#include "pawn.hh"

#include <QGraphicsPixmapItem>
#include <QGraphicsSceneMouseEvent>
#include <QPixmap>
#include <QGraphicsEffect>
#include <QGraphicsColorizeEffect>
#include <QPropertyAnimation>

/* Impelents a playable pawn on the gameboard.
 * Pawns can be moved around, use vehicles and be eaten by actors.
 */


class GameRunner;
class GamePiece :public QObject, public QGraphicsPixmapItem, public Common::Pawn
{
    Q_OBJECT
    Q_PROPERTY(QPointF pos READ pos WRITE setPos)

public:
    GamePiece(int pawnId, int playerId,
              Common::CubeCoordinate pawnCoord, std::shared_ptr<GameRunner> gameRunner);
    ~GamePiece();

    void movementAnimation(QPointF target);
    void boardTransport(int transportId);
    void unboardTransport();
    bool isOnTransport();
    int getTransportId();



protected:
     void mousePressEvent(QGraphicsSceneMouseEvent *event);

private:
    double SCALE_;
    //double scaleHighlight_;

    int pieceId_;
    int ownerId_;
    int transportId_;
    Common::CubeCoordinate pieceCoord_;

    std::shared_ptr<GameRunner> gameRunner_;
    QPropertyAnimation* movementAnimation_;
    QGraphicsColorizeEffect* colorEffect_;

    void setColor();

    bool clickable_ = true;
    bool isOnTransport_ = false;
};

#endif // GAMEPIECE_HH
