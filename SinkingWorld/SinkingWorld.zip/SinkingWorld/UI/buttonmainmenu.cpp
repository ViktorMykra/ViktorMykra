#include "buttonmainmenu.hh"
#include "mainmenu.hh"

ButtonMainMenu::ButtonMainMenu(std::string buttonType, MainMenu* menu) :
    buttonType_(buttonType), menu_(menu)
{
    this->setAcceptHoverEvents(true);
    this->setShapeMode(QGraphicsPixmapItem::BoundingRectShape);

    QString imagePath((":/images/buttonimages/" + buttonType_ + ".png").c_str());
    image_ = QPixmap(imagePath);

    QString imagePathHover((":/images/buttonimages/" + buttonType_ + "_hover.png").c_str());
    imageHover_ = QPixmap(imagePathHover);

    this->setPixmap(image_);
}

void ButtonMainMenu::setClickable()
{
    if(!clickable_){
        clickable_ = 1;
    }
}

void ButtonMainMenu::setUnclickable()
{
    if(clickable_){
        clickable_ = 0;
    }
}

void ButtonMainMenu::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    if(event->button() == Qt::LeftButton and clickable_){
        if(buttonType_ == "newgame"){
            this->setPixmap(image_);
            menu_->newgame();
        }
        if(buttonType_ == "settings"){
            this->setPixmap(image_);
            menu_->settings();
        }
        if(buttonType_ == "highscores"){  
            this->setPixmap(image_);
            menu_->highscore();
        }
        if(buttonType_ == "close_highscores"){          
            this->setPixmap(image_);
            menu_->highscoreClose();
        }
        if(buttonType_ == "info"){            
            this->setPixmap(image_);
            menu_->info();
        }
        if(buttonType_ == "close_info"){            
            this->setPixmap(image_);
            menu_->infoClose();
        }
        if(buttonType_ == "help"){
            this->setPixmap(image_);
            menu_->help();
        }
        if(buttonType_ == "close_help"){            
            this->setPixmap(image_);
            menu_->helpClose();
        }
        if(buttonType_ == "header"){
            this->scene()->setBackgroundBrush(QBrush(QColor(rand()%255, rand()%255, rand()%255)));
        }
    }
}

void ButtonMainMenu::hoverEnterEvent(QGraphicsSceneHoverEvent *event)
{
    if(clickable_){  
        event->accept();
        this->setPixmap(imageHover_);
    }
}

void ButtonMainMenu::hoverLeaveEvent(QGraphicsSceneHoverEvent *event)
{
    if(clickable_){
        event->accept();
        this->setPixmap(image_);
    }

}
