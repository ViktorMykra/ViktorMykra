#ifndef BUTTON_HH
#define BUTTON_HH


#include <QGraphicsPixmapItem>
#include <QGraphicsSceneMouseEvent>
#include <QPixmap>

// Impelents custom buttons for mainmenu scene.


class MainMenu;
class ButtonMainMenu : public QGraphicsPixmapItem {

public:
    ButtonMainMenu(std::string buttonType, MainMenu* menu);
    ~ButtonMainMenu()=default;
    void setClickable();
    void setUnclickable();

protected:
    void mousePressEvent(QGraphicsSceneMouseEvent *event);
    void hoverEnterEvent(QGraphicsSceneHoverEvent *event);
    void hoverLeaveEvent(QGraphicsSceneHoverEvent *event);

private:

    std::string buttonType_;
    MainMenu* menu_;

    bool clickable_ = 1;

    QPixmap image_;
    QPixmap imageHover_;

};

#endif // BUTTON_HH
