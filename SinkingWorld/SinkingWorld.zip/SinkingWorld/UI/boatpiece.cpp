#include "boatpiece.hh"
#include "gamerunner.hh"
#include "gameboard.hh"

BoatPiece::BoatPiece(int id, std::shared_ptr<GameRunner> gameRunner, GameBoard* gameBoard) :
    Transport(id),
    gameRunner_(gameRunner),
    gameBoard_(gameBoard)
{
    this->setToolTip(QString("Boat, can carry 4 pawns."));
    capacity_ = 4;
    this->setPixmap(QPixmap(QString(":/images/buttonimages/boat.png")));

    movementAnimation_ = new QPropertyAnimation(this, "pos");

    this->setScale(0.4);
    this->setZValue(-4);

}

BoatPiece::~BoatPiece()
{}

void BoatPiece::movementAnimation(QPointF target)
{
    movementAnimation_->setDuration(450);
    movementAnimation_->setStartValue(this->pos());
    movementAnimation_->setEndValue(target);
    movementAnimation_->start();
}

std::string BoatPiece::getTransportType()
{
    return "boat";
}

std::vector<std::shared_ptr<Common::Pawn>> BoatPiece::getPawnsInTransport()
{
    return pawns_;
}

void BoatPiece::move(std::shared_ptr<Common::Hex> to)
{
    Common::CubeCoordinate targetCoord = to->getCoordinates();

    QPointF targetXY = gameBoard_->getHexXY(targetCoord);
    qreal targetX = targetXY.rx() - 30.0;
    qreal targetY = targetXY.ry() - 35.0;

    std::vector<std::shared_ptr<Common::Pawn>> pawnsOnBoard = pawns_;

    int pawnId;

    for(unsigned int i = 0; i < pawnsOnBoard.size(); ++i){
        pawnId = pawnsOnBoard.at(i)->getId();
        std::shared_ptr<GamePiece> pawn = gameBoard_->getGamePiece(pawnId);
        pawn->movementAnimation(QPointF(targetX - 20, targetY + (i * 10)));
        pawn->setCoordinates(targetCoord);
    }

    this->movementAnimation(QPointF(targetX, targetY));
    addHex(to);
}

bool BoatPiece::canMove(int playerId) const
{
    int pawnCount = static_cast<int>(pawns_.size());
    int counter = 0;

    if(pawns_.size() == 0){
        return true;
    }

    for(unsigned int i = 0; i < pawns_.size(); ++i){
        if(pawns_.at(i)->getPlayerId() == playerId){
            counter += 1;
        }
    }

    double result = counter / pawnCount;

    if(result > 0.5){
        return true;
    }
    else{
        return false;
    }
}

void BoatPiece::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    gameRunner_->transportPress(shared_from_this());
    event->accept();
}
