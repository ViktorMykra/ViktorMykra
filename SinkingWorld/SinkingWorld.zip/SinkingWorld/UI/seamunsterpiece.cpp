#include "seamunsterpiece.hh"

#include "gameboard.hh"
#include "gamerunner.hh"

SeamunsterPiece::SeamunsterPiece(int id, std::shared_ptr<GameRunner> gameRunner, GameBoard* gameBoard) :
    id_(id),
    gameRunner_(gameRunner),
    gameBoard_(gameBoard)
{
    this->setToolTip(QString("Seamunster, eats pawns and boats."));
    this->setPixmap(QPixmap(QString(":/images/buttonimages/seamuncher.png")));

    movementAnimation_ = new QPropertyAnimation(this, "pos");

    this->setTransformOriginPoint(25, 25);
    this->setZValue(-4);

    connect(movementAnimation_, SIGNAL(finished()), this, SLOT(animationFinished()));
}

void SeamunsterPiece::move(std::shared_ptr<Common::Hex> to)
{
    if(hex1_ != nullptr){
        hex1_->removeActor(shared_from_this());
    }

    QPointF target = gameBoard_->getHexXY(to->getCoordinates());
    qreal targetX = target.rx()-25;
    qreal targetY = target.ry()-25;
    movementAnimation(QPointF(targetX, targetY));
    to->addActor(shared_from_this());
    addHex(to);

}

void SeamunsterPiece::doAction()
{
    //getHex()->clearPawnsFromTerrain();

    std::vector<std::shared_ptr<Common::Pawn>> pawns = getHex()->getPawns();
    for(unsigned int i = 0; i < pawns.size(); ++i){
        int pawnId = pawns.at(i)->getId();
        std::shared_ptr<GamePiece> pawn = gameBoard_->getGamePiece(pawnId);

        if(!(pawn->isOnTransport())){
            gameBoard_->removePawn(pawnId);
        }
    }

    std::vector<std::shared_ptr<Common::Transport>> transports = getHex()->getTransports();
    for(unsigned int j = 0; j < transports.size(); ++j){
         std::vector<std::shared_ptr<Common::Pawn>> pawnsOnTrans = transports.at(j)->getPawnsInTransport();
         for(unsigned int k = 0; k < pawnsOnTrans.size(); ++k){
             gameBoard_->removePawn(pawnsOnTrans.at(k)->getId());
         }
         getHex()->removeTransport(transports.at(j));
         gameBoard_->removeTransport(transports.at(j)->getId());
    }
}

std::string SeamunsterPiece::getActorType() const
{
    return "seamunster";
}

int SeamunsterPiece::getId() const
{
    return id_;
}

void SeamunsterPiece::addHex(std::shared_ptr<Common::Hex> hex)
{
    hex1_ = hex;
}

std::shared_ptr<Common::Hex> SeamunsterPiece::getHex()
{
    return hex1_;
}

void SeamunsterPiece::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    event->accept();
    gameRunner_->actorPress(shared_from_this());
}

void SeamunsterPiece::animationFinished()
{
    doAction();
}

void SeamunsterPiece::movementAnimation(QPointF target)
{
    movementAnimation_->setDuration(450);
    movementAnimation_->setStartValue(this->pos());
    movementAnimation_->setEndValue(target);
    movementAnimation_->start();

}
