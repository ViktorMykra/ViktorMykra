#ifndef GAMESTATE_HH
#define GAMESTATE_HH

#include "igamestate.hh"

/* Game state class for keeping track of current gamestate
 */

class GameState : public Common::IGameState
{
public:
    GameState();
    ~GameState()=default;
    Common::GamePhase currentGamePhase() const;
    int currentPlayer() const;
    void changeGamePhase(Common::GamePhase nextPhase);
    void changePlayerTurn(int nextPlayer);

private:
    Common::GamePhase gamePhase_;
    int currentPlayer_;


};

#endif // GAMESTATE_HH
