#include "gamestate.hh"
#include <QtDebug>

GameState::GameState()
{
    gamePhase_ = Common::MOVEMENT;
    currentPlayer_ = 1;
}

Common::GamePhase GameState::currentGamePhase() const
{
    return gamePhase_;
}

int GameState::currentPlayer() const
{
    return currentPlayer_;
}

void GameState::changeGamePhase(Common::GamePhase nextPhase)
{
    gamePhase_ = nextPhase;
}

void GameState::changePlayerTurn(int nextPlayer)
{
    currentPlayer_ = nextPlayer;
}
