#ifndef PLAYER_HH
#define PLAYER_HH

#include "iplayer.hh"
#include <string>

/* Impelents a player class for keeping track of players and their points.
 */


class Player : public Common::IPlayer
{
public:
    Player(int playerId, std::string playerName);
    ~Player()=default;

    int getPlayerId() const;
    std::string getPlayerName() const;
    unsigned int getActionsLeft() const;
    void setActionsLeft(unsigned int actionsLeft);
    int getPoints();
    void addPoint();

private:
    int playerId_;
    std::string playerName_;
    unsigned int actionsLeft_;
    int points_ = 0;
};

#endif // PLAYER_HH
