#include "mainmenu.hh"
#include "gameboard.hh"

#include <QPushButton>
#include <QGraphicsItem>
#include <QPixmap>
#include <QMessageBox>
#include <string>
#include <QTextStream>

MainMenu::MainMenu(GameBoard* gameBoard) :
    gameBoard_(gameBoard)
{
    createAssets();
    showMenuButtons();
}

MainMenu::~MainMenu()
{
    releaseAssets();
}

void MainMenu::newgame()
{
    hideMenuButtons();
    this->addItem(newgameButton_);
    newgameButton_->setUnclickable();

    //Create message box and message for newgame prompt
    QMessageBox newgamemsg;
    newgamemsg.setWindowTitle("New Game");
    newgamemsg.setText("Star new game?");
    std::string str = "Player count: " + std::to_string(playerCount);
    std::string str1("\nPlayer 1 name: "+ player1);
    std::string str2("\nPlayer 2 name: "+ player2);
    std::string str3("\nPlayer 3 name: "+ player3);
    std::string str4("\nPlayer 4 name: "+ player4);

    if(playerCount == 1){
        str2 = "";
        str3 = "";
        str4 = "";
    }
    if(playerCount == 2){
        str3 = "";
        str4 = "";
    }
    if(playerCount == 3){
        str4 = "";
    }

    std::string message = str + str1 + str2 + str3 + str4;

    newgamemsg.setDetailedText(QString::fromStdString(message));
    newgamemsg.setStandardButtons(QMessageBox::Ok | QMessageBox::Cancel);
    newgamemsg.move(200, 670);
    int startmsg = newgamemsg.exec();

    if(startmsg == QMessageBox::Ok){
        playerNames.push_back(player1);
        playerNames.push_back(player2);
        playerNames.push_back(player3);
        playerNames.push_back(player4);
        this->removeItem(newgameButton_);
        newgameButton_->setClickable();

        showMenuButtons();

        gameBoard_->startNewGame();

    }
    else{
        newgameButton_->setClickable();
        this->removeItem(newgameButton_);
        showMenuButtons();
    }
}

void MainMenu::settings()
{
    hideMenuButtons();
    this->addItem(settingsButton_);
    settingsButton_->setUnclickable();

    //Create dialog
    SettingsDialog settings(playerCount, player1, player2, player3, player4);
    settings.move(200, 600);
    settings.exec();

    //Save settings
    playerCount = settings.players;
    player1 = settings.getPlayer1Name();
    player2 = settings.getPlayer2Name();
    player3 = settings.getPlayer3Name();
    player4 = settings.getPlayer4Name();

    settingsButton_->setClickable();
    this->removeItem(settingsButton_);
    showMenuButtons();
}

void MainMenu::highscore()
{
    hideMenuButtons();

    this->addItem(closeHighscoreButton_);
    highscoreButton_->setUnclickable();

    this->addItem(highscoreButton_);
    this->addItem(highscoresText_);
}

void MainMenu::highscoreClose()
{
    highscoreButton_->setClickable();
    this->removeItem(highscoreButton_);
    this->removeItem(closeHighscoreButton_);
    this->removeItem(highscoresText_);
    showMenuButtons();
}

void MainMenu::help()
{
    hideMenuButtons();

    this->addItem(helpButton_);
    helpButton_->setUnclickable();

    this->addItem(closeHelpButton_);
    this->addItem(helpText_);
}

void MainMenu::helpClose()
{
    helpButton_->setClickable();
    this->removeItem(helpButton_);
    this->removeItem(closeHelpButton_);
    this->removeItem(helpText_);
    showMenuButtons();
}


void MainMenu::info()
{
    hideMenuButtons();

    this->addItem(infoButton_);
    infoButton_->setUnclickable();

    this->addItem(closeInfoButton_);
    this->addItem(infoText_);
}

void MainMenu::infoClose()
{
    infoButton_->setClickable();
    this->removeItem(infoButton_);
    this->removeItem(closeInfoButton_);
    this->removeItem(infoText_);
    showMenuButtons();
}

//Creating and positioning buttons:
void MainMenu::createAssets()
{

    this->setBackgroundBrush(Qt::white);


    header_ = new ButtonMainMenu("header", this);
    header_->setOffset(100, 0);
    this->addItem(header_);

    newgameButton_ = new ButtonMainMenu("newgame", this);
    newgameButton_->setOffset(10, 600);

    settingsButton_ = new ButtonMainMenu("settings", this);
    settingsButton_->setOffset(10, 640);

    highscoreButton_ = new ButtonMainMenu("highscores", this);
    highscoreButton_->setOffset(10, 680);

    closeHighscoreButton_ = new ButtonMainMenu("close_highscores", this);
    closeHighscoreButton_->setOffset(800, 680);

    helpButton_ = new ButtonMainMenu("help", this);
    helpButton_->setOffset(10, 720);

    closeHelpButton_ = new ButtonMainMenu("close_help", this);
    closeHelpButton_->setOffset(800, 720);

    infoButton_ = new ButtonMainMenu("info", this);
    infoButton_->setOffset(10, 760);

    closeInfoButton_ = new ButtonMainMenu("close_info", this);
    closeInfoButton_->setOffset(800, 760);

    infoText_ = new QGraphicsTextItem();

    QFile infoFile(":/files/textfiles/infotext.txt");

    QString infoContent;

    if(infoFile.open(QIODevice::ReadOnly)){
        QTextStream stream1(&infoFile);
        infoContent = stream1.readAll();
    }
    else{
        infoContent = "Please reinstall the game. Theres missing files.";
    }
    infoFile.close();

    infoText_->setTextWidth(600);
    infoText_->setPlainText(infoContent);
    infoText_->setPos(150,200);

    helpText_ = new QGraphicsTextItem();

    QFile helpFile(":/files/textfiles/helptext.txt");
    QString helpContent;

    if(helpFile.open(QIODevice::ReadOnly)){
        QTextStream helpStream(&helpFile);
        helpContent = helpStream.readAll();
    }
    else{
        helpContent = "Please reinstall the game. Theres missing files.";
    }
    helpFile.close();

    helpText_->setTextWidth(600);
    helpText_->setPlainText(helpContent);
    this->
    helpText_->setPos(150,200);

    highscoresText_ = new QGraphicsTextItem();

    QFile hsFile(":/files/textfiles/highscores.txt");
    QString hsContent;
    if(hsFile.open(QIODevice::ReadOnly)){
        QTextStream hsStream(&hsFile);
        hsContent = hsStream.readAll();
    }
    else{
        hsContent = "Please reinstall the game. Theres missing files.";
    }
    hsFile.close();

    highscoresText_->setTextWidth(600);
    highscoresText_->setPlainText(hsContent);
    highscoresText_->setPos(400,200);
}

void MainMenu::releaseAssets()
{
    /*
    delete header_;
    delete newgameButton_;
    delete settingsButton_;
    delete highscoreButton_;
    delete closeHighscoreButton_;
    delete helpButton_;
    delete closeHelpButton_;
    delete infoButton_;
    delete closeInfoButton_;
    delete infoText_;
    delete helpText_;
    delete highscoresText_;
    delete this;*/

    //Caused crash on exit. DO VALGRIND

}

void MainMenu::showMenuButtons()
{
    this->addItem(newgameButton_);
    this->addItem(settingsButton_);
    this->addItem(highscoreButton_);
    this->addItem(helpButton_);
    this->addItem(infoButton_);
}
void MainMenu::hideMenuButtons()
{
    this->removeItem(newgameButton_);
    this->removeItem(settingsButton_);
    this->removeItem(highscoreButton_);
    this->removeItem(helpButton_);
    this->removeItem(infoButton_);
}

