#include <player.hh>


Player::Player(int playerId, std::string playerName) :
    playerId_(playerId),
    playerName_(playerName)
{
    actionsLeft_ = 0;
}

int Player::getPlayerId() const
{
    return playerId_;
}

std::string Player::getPlayerName() const
{
    return playerName_;
}

unsigned int Player::getActionsLeft() const
{
    return actionsLeft_;
}

void Player::setActionsLeft(unsigned int actionsLeft)
{
    actionsLeft_ = actionsLeft;
}

int Player::getPoints()
{
    return points_;
}

void Player::addPoint()
{
    points_ += 1;
}
