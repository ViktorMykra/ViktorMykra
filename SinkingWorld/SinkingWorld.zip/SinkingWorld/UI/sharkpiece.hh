#ifndef SHARKPIECE_HH
#define SHARKPIECE_HH

#include "actor.hh"

#include <QObject>
#include <QGraphicsPixmapItem>
#include <QPropertyAnimation>

/* Impelents a playable shark on the gameboard.
 * Shark eats pawns in water.
 */


class GameRunner;
class GameBoard;

class SharkPiece : public QObject, public QGraphicsPixmapItem, public Common::Actor
{
    Q_OBJECT
    Q_PROPERTY(QPointF pos READ pos WRITE setPos)
    
public:
    SharkPiece(int id, std::shared_ptr<GameRunner> gameRunner, GameBoard* gameBoard);
    ~SharkPiece()=default;
    
    void move(std::shared_ptr<Common::Hex> to );
    void doAction();
    std::string getActorType() const;
    int getId() const;
    void addHex(std::shared_ptr<Common::Hex> hex);
    std::shared_ptr<Common::Hex> getHex();

protected:
    void mousePressEvent(QGraphicsSceneMouseEvent *event);

private slots:
    void animationFinished();

private:
    int id_;
    std::shared_ptr<GameRunner> gameRunner_;
    GameBoard* gameBoard_;
    QPropertyAnimation* movementAnimation_;

    std::shared_ptr<Common::Hex> hex1_;

    void movementAnimation(QPointF target);




};

#endif // SHARKPIECE_HH
