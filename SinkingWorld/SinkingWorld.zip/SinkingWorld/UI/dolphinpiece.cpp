#include "dolphinpiece.hh"
#include "gamerunner.hh"
#include "gameboard.hh"

DolphinPiece::DolphinPiece(int id, std::shared_ptr<GameRunner> gameRunner, GameBoard* gameBoard) :
    Transport(id),
    gameRunner_(gameRunner),
    gameBoard_(gameBoard)
{
    this->setToolTip(QString("Dolphin, can carry 1 pawn."));
    capacity_ = 1;
    this->setPixmap(QPixmap(QString(":/images/buttonimages/dolphin.png")));

    movementAnimation_ = new QPropertyAnimation(this, "pos");

    this->setScale(0.4);
    this->setZValue(-4);
}

std::string DolphinPiece::getTransportType()
{
    return "dolphin";
}

std::vector<std::shared_ptr<Common::Pawn>> DolphinPiece::getPawnsInTransport()
{
    return pawns_;
}

void DolphinPiece::move(std::shared_ptr<Common::Hex> to)
{
    Common::CubeCoordinate targetCoord = to->getCoordinates();

    QPointF targetXY = gameBoard_->getHexXY(targetCoord);
    qreal targetX = targetXY.rx() - 30.0;
    qreal targetY = targetXY.ry() - 35.0;

    std::vector<std::shared_ptr<Common::Pawn>> pawnsOnBoard = pawns_;

    int pawnId;

    for(unsigned int i = 0; i < pawnsOnBoard.size(); ++i){
        pawnId = pawnsOnBoard.at(i)->getId();
        std::shared_ptr<GamePiece> pawn = gameBoard_->getGamePiece(pawnId);
        pawn->movementAnimation(QPointF(targetX, targetY));
        pawn->setCoordinates(targetCoord);
    }

    movementAnimation(QPointF(targetX, targetY));
    addHex(to);
}

bool DolphinPiece::canMove(int playerId) const
{
    int pawnCount = static_cast<int>(pawns_.size());
    int counter = 0;

    if(pawns_.size() == 0){
        return true;
    }

    for(unsigned int i = 0; i < pawns_.size(); ++i){
        if(pawns_.at(i)->getPlayerId() == playerId){
            counter += 1;
        }
    }

    double result = counter / pawnCount;

    if(result > 0.5){
        return true;
    }
    else{
        return false;
    }
}

void DolphinPiece::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    gameRunner_->transportPress(shared_from_this());
    event->accept();
}

void DolphinPiece::movementAnimation(QPointF target)
{
    movementAnimation_->setDuration(450);
    movementAnimation_->setStartValue(this->pos());
    movementAnimation_->setEndValue(target);
    movementAnimation_->start();
}
