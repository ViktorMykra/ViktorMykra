#ifndef DOLPHINPIECE_HH
#define DOLPHINPIECE_HH

#include "transport.hh"

#include <QObject>
#include <QPropertyAnimation>
#include <QGraphicsPixmapItem>

/*Impelents a playable dolphin on the gameboard.
 * Boat can carry 1 pawns around in water hexes.
 */


class GameRunner;
class GameBoard;
class DolphinPiece:public QObject, public QGraphicsPixmapItem, public Common::Transport
{
    Q_OBJECT
    Q_PROPERTY(QPointF pos READ pos WRITE setPos)

public:
    DolphinPiece(int id, std::shared_ptr<GameRunner> gameRunner, GameBoard* gameBoard);
    ~DolphinPiece()=default;

public:
    std::string getTransportType();

    std::vector<std::shared_ptr<Common::Pawn>> getPawnsInTransport();

    void move(std::shared_ptr<Common::Hex> to);

    bool canMove(int playerId) const;

protected:
    void mousePressEvent(QGraphicsSceneMouseEvent *event);

private:
    std::shared_ptr<GameRunner> gameRunner_;
    
    GameBoard* gameBoard_;
    
    QPropertyAnimation* movementAnimation_;

    Common::CubeCoordinate coord_;
    
    void movementAnimation(QPointF target);



};

#endif // DOLPHINPIECE_HH
