#ifndef VORTEXPIECE_HH
#define VORTEXPIECE_HH

#include "actor.hh"

#include <QObject>
#include <QGraphicsPixmapItem>
#include <QPropertyAnimation>

/* Impelents a vortex on the gameboard.
 * Vortex destroys boats and pawns.
 */


class GameRunner;
class GameBoard;

class VortexPiece : public QObject, public QGraphicsPixmapItem, public Common::Actor
{
    Q_OBJECT
    Q_PROPERTY(qreal rotation READ rotation WRITE setRotation)

public:
    VortexPiece(int id, std::shared_ptr<GameRunner> gameRunner, GameBoard* gameBoard);
    ~VortexPiece()=default;

    void move(std::shared_ptr<Common::Hex> to);
    void doAction();
    std::string getActorType() const;
    int getId() const;
    void addHex(std::shared_ptr<Common::Hex> hex);
    std::shared_ptr<Common::Hex> getHex();

protected:
    void mousePressEvent(QGraphicsSceneMouseEvent *event);

private slots:
    void animationFinished();

private:
    int id_;
    std::shared_ptr<GameRunner> gameRunner_;
    GameBoard* gameBoard_;
    QPropertyAnimation* rotationAnimation_;

    std::shared_ptr<Common::Hex> hex1_;

    void rotationAnimation();
};

#endif // VORTEXPIECE_HH
