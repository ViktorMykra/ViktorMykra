#include "gameboard.hh"
#include <QtMath>
#include <stdlib.h>
#include <QMessageBox>
#include <QString>

GameBoard::GameBoard()
{
    setFixedSize(1200, 900);
    showMainMenu();

}

int GameBoard::checkTileOccupation(Common::CubeCoordinate tileCoord) const
{
    std::shared_ptr<Common::Hex> targetHex = getHex(tileCoord);

    if (targetHex == nullptr){
        return -1;
    }
    else{
        return targetHex->getPawnAmount();
    }
}

bool GameBoard::isWaterTile(Common::CubeCoordinate tileCoord) const
{
    for(size_t i = 0; i < hexPiecesCommon_.size(); ++i){
        if(hexPiecesCommon_.at(i)->getCoordinates() == tileCoord){
            if(hexPiecesCommon_.at(i)->getPieceType() == "Water"){
                return true;
            }
            else{
                return false;
            }
        }
    }
    return false;
}

std::shared_ptr<Common::Hex> GameBoard::getHex(Common::CubeCoordinate hexCoord) const
{
    for(unsigned int i = 0; i < hexPiecesCommon_.size(); ++i){
        if(hexPiecesCommon_.at(i)->getCoordinates() == hexCoord){
            return hexPiecesCommon_.at(i);
        }
    }
    return nullptr;
}

std::shared_ptr<GamePiece> GameBoard::getGamePiece(int pawnId) const
{
    for(unsigned int i = 0; i < gamePieces_.size(); ++i){
        if(gamePieces_.at(i)->getId() == pawnId){
            return gamePieces_.at(i);
        }
    }
    return nullptr;
}

std::shared_ptr<Common::Actor> GameBoard::getActor(int id) const
{
    for(unsigned int i = 0; i < actors_.size(); ++i){
        if(id == actors_.at(i)->getId()){
            return actors_.at(i);
        }
    }
    return nullptr;
}

std::shared_ptr<Common::Transport> GameBoard::getTransport(int id) const
{
    for(unsigned int i = 0; i < transports_.size(); ++i){
        if(id == transports_.at(i)->getId()){
            return transports_.at(i);
        }
    }
    return nullptr;
}

std::shared_ptr<HexPiece> GameBoard::getHexPiece(Common::CubeCoordinate hexCoord) const
{
    for(size_t i = 0; i < hexPieces_.size(); ++i){
        if(hexPieces_.at(i)->getCoordinates() == hexCoord){
            return hexPieces_.at(i);
        }
    }
    return nullptr;
}

void GameBoard::addPawn(int playerId, int pawnId)
{
    int asd = playerId + pawnId;
    asd += 1;
}

void GameBoard::addPawn(int playerId, int pawnId, Common::CubeCoordinate coord)
{
    std::shared_ptr<HexPiece> targetHex = getHexPiece(coord);

    if(targetHex != nullptr){

        int targetPawnAmount = targetHex->getPawnAmount();

        if(targetPawnAmount < 4){

            std::vector<double> offsets = getOffsets(targetPawnAmount);

            double xOffset = offsets.at(0);
            double yOffset = offsets.at(1);
            double xCoord = targetHex->x() + xOffset;
            double yCoord = targetHex->y() + yOffset;

            Common::CubeCoordinate coord = targetHex->getCoordinates();

            std::shared_ptr<GamePiece> piece =
                    std::make_shared<GamePiece>(pawnId, playerId, coord, gameRunner_);

            piece->setPos(xCoord, yCoord);

            gameBoardScene_->addItem(piece.get());
            targetHex->addPawn(piece);
            gamePieces_.push_back(piece);
        }
    }
}

void GameBoard::movePawn(int pawnId, Common::CubeCoordinate pawnCoord)
{
    std::shared_ptr<GamePiece> movingPawn = nullptr;
    std::shared_ptr<HexPiece> targetHex = getHexPiece(pawnCoord);

    for(unsigned int i = 0; i < gamePieces_.size(); ++i){
        if(pawnId == gamePieces_.at(i)->getId()){
            movingPawn = gamePieces_.at(i);
        }
    }

    std::shared_ptr<HexPiece> startingHex = getHexPiece(movingPawn->getCoordinates());

    if((movingPawn != nullptr) && (targetHex != nullptr) && (startingHex != nullptr)){


        int targetPawnCount = targetHex->getPawnAmount();

        if(targetPawnCount < 4){
            std::vector<double> offsets = getOffsets(targetPawnCount);
            double xOffset = offsets.at(0);
            double yOffset = offsets.at(1);
            double targetXCoord = targetHex->x() + xOffset;
            double targetYCoord = targetHex->y() + yOffset;

            movingPawn->movementAnimation(QPointF(targetXCoord, targetYCoord));
            movingPawn->setCoordinates(pawnCoord);

            startingHex->removePawn(movingPawn);
            targetHex->addPawn(movingPawn);
        }

    }
}

void GameBoard::removePawn(int pawnId)
{
    for(unsigned int i = 0; i < gamePieces_.size(); ++i){
        if(pawnId == gamePieces_.at(i)->getId()){
            std::shared_ptr<GamePiece> pawnToRemove = gamePieces_.at(i);
            Common::CubeCoordinate coord = pawnToRemove->getCoordinates();
            std::shared_ptr<HexPiece> hexToRemoveFrom = getHexPiece(coord);
            hexToRemoveFrom->removePawn(pawnToRemove);
            gamePieces_.erase(gamePieces_.begin() + i);
            gameBoardScene_->removeItem(pawnToRemove.get());

        }
    }
}

void GameBoard::createActor(std::string type, Common::CubeCoordinate hex)
{
    int actorId = static_cast<int>(actors_.size()) + static_cast<int>(hexPieces_.size()); // Always bigger than transportIds

    if(type == "shark"){
        std::shared_ptr<SharkPiece> newShark = std::make_shared<SharkPiece>(actorId, gameRunner_, this);
        newShark->setData(0, QVariant(actorId));
        gameBoardScene_->addItem(newShark.get());
        newShark->setPos(getHexXY(hex));
        addActor(newShark, hex);
    }
    else if(type=="vortex"){
        std::shared_ptr<VortexPiece> newVortex = std::make_shared<VortexPiece>(actorId, gameRunner_, this);
        newVortex->setData(0, QVariant(actorId));
        gameBoardScene_->addItem(newVortex.get());
        newVortex->setPos(getHexXY(hex));
        addActor(newVortex, hex);
    }
    else if(type=="kraken"){
        std::shared_ptr<KrakenPiece> newKraken = std::make_shared<KrakenPiece>(actorId, gameRunner_, this);
        newKraken->setData(0, QVariant(actorId));
        gameBoardScene_->addItem(newKraken.get());
        newKraken->setPos(getHexXY(hex));
        addActor(newKraken, hex);
    }
    else if(type=="seamunster"){
        std::shared_ptr<SeamunsterPiece> newSeamunster = std::make_shared<SeamunsterPiece>(actorId, gameRunner_, this);
        newSeamunster->setData(0, QVariant(actorId));
        gameBoardScene_->addItem(newSeamunster.get());
        newSeamunster->setPos(getHexXY(hex));
        addActor(newSeamunster, hex);
    }
}

void GameBoard::addActor(std::shared_ptr<Common::Actor> actor, Common::CubeCoordinate actorCoord)
{
    std::shared_ptr<Common::Hex> targetHex = getHex(actorCoord);
    actor->move(targetHex);
    actors_.push_back(actor);
}

void GameBoard::moveActor(int actorId, Common::CubeCoordinate actorCoord)
{
    std::shared_ptr<Common::Actor> actor = getActor(actorId);
    if(actor != nullptr){
        actor->move(getHex(actorCoord));
    }
}

void GameBoard::removeActor(int actorId)
{
    QList<QGraphicsItem *> itemsInScene = gameBoardScene_->items();

    for(int i = 0; i < itemsInScene.size(); ++i){
        if(itemsInScene.at(i)->data(0) == actorId){
            gameBoardScene_->removeItem(itemsInScene.at(i));
        }
    }
    for(unsigned int i = 0; i < actors_.size(); ++i){
        if(actors_.at(i)->getId() == actorId){
            actors_.erase(actors_.begin() + i);
        }
    }
}

void GameBoard::addHex(std::shared_ptr<Common::Hex> newHex)
{
    hexPiecesCommon_.push_back(newHex);
}

void GameBoard::createTransport(std::string type, Common::CubeCoordinate hex)
{
    int transportId = static_cast<int>(transports_.size()) + 1;


    if(type == "dolphin"){
        std::shared_ptr<DolphinPiece> newDolphin = std::make_shared<DolphinPiece>(transportId, gameRunner_, this);
        newDolphin->setData(0, QVariant(transportId));
        gameBoardScene_->addItem(newDolphin.get());
        newDolphin->setPos(getHexXY(hex));
        addTransport(newDolphin, hex);
    }
    if(type == "boat"){
        std::shared_ptr<BoatPiece> newBoat = std::make_shared<BoatPiece>(transportId, gameRunner_, this);
        newBoat->setData(0, QVariant(transportId));
        gameBoardScene_->addItem(newBoat.get());
        newBoat->setPos(getHexXY(hex));
        addTransport(newBoat, hex);
    }
}

void GameBoard::addTransport(std::shared_ptr<Common::Transport> transport, Common::CubeCoordinate coord)
{
    std::shared_ptr<Common::Hex> targetHex = getHex(coord);

    transport->move(targetHex);

    transports_.push_back(transport);
}

void GameBoard::moveTransport(int id, Common::CubeCoordinate coord)
{
    std::shared_ptr<Common::Transport> transprot = getTransport(id);
    if(transprot != nullptr){
        transprot->move(getHex(coord));
    }
}

void GameBoard::removeTransport(int id)
{
    QList<QGraphicsItem *> itemsInScene = gameBoardScene_->items();
    for(int i = 0; i < itemsInScene.size(); ++i){
        if(itemsInScene.at(i)->data(0) == id){
            gameBoardScene_->removeItem(itemsInScene.at(i));
        }
    }

    for(unsigned int i = 0; i < transports_.size(); ++i){
        if(transports_.at(i)->getId() == id){
            transports_.erase(transports_.begin() + i);
        }
    }
}

void GameBoard::startNewGame()
{
    int playerCount = mainMenuScene_->playerCount;
    std::vector<std::string> playerNames = mainMenuScene_->playerNames;

    for(auto playerId = 1; playerId <= playerCount; ++playerId){

        std::string playerName = playerNames.at(static_cast<size_t>(playerId - 1)); //-1 'cause index

        std::shared_ptr<Player> newPlayer =
                std::make_shared<Player>(playerId, playerName);
        players_.push_back(newPlayer);
    }

    setUpGameBoard();
    setUpPawns(playerCount);
    this->setScene(gameBoardScene_.get());

}

bool GameBoard::isGameOver()
{
    if(gamePieces_.size() == 0){
        return true;
    }
    return false;
}

void GameBoard::finishGame()
{
    QMessageBox finisher;
    finisher.setModal(true);
    finisher.setWindowTitle("Game has ended");
    std::string winner;
    int points = -1;

    for(unsigned int i = 0; i < players_.size(); ++i){
        if(players_.at(i)->getPoints() > points){
            winner = players_.at(i)->getPlayerName();
        }   points = players_.at(i)->getPoints();
    }

    std::string message = "Winner is " + winner + " with: " + std::to_string(points) + " points";
    finisher.setText(QString::fromStdString(message));
    finisher.setStandardButtons(QMessageBox::Ok);
    finisher.exec();

    this->setScene(mainMenuScene_.get());

    if(gameBoardScene_ != nullptr){
        QList<QGraphicsItem *> itemsInScene = gameBoardScene_->items();
        for(int i = 0; i < itemsInScene.size(); ++i){
            gameBoardScene_->removeItem(itemsInScene.at(i));
        }
    }

    transports_.erase(transports_.begin(), transports_.end());
    hexPieces_.erase(hexPieces_.begin(), hexPieces_.end());
    hexPiecesCommon_.erase(hexPiecesCommon_.begin(), hexPiecesCommon_.end());
    actors_.erase(actors_.begin(), actors_.end());
    playerScores_.erase(playerScores_.begin(), playerScores_.end());
    players_.erase(players_.begin(), players_.end());
    hintMessage_ = nullptr;
    skipTurnButton_ = nullptr;

    wheel_ = nullptr;
    wheelArrow_ = nullptr;

    gameRunner_ = nullptr;
    gameBoardScene_ = nullptr;



}

void GameBoard::setHint(std::string message)
{
    hintMessage_->setText(QString::fromStdString(message));
    QRectF boundingRect = hintMessage_->boundingRect();
    hintMessage_->setScale(2);
    hintMessage_->setPos((boundingRect.width() * -1), -450);
    hintMessage_->setBrush(Qt::white);

}

void GameBoard::setScoreBoard(std::vector<std::string> playerStats)
{
    for(unsigned int i = 0; i < playerStats.size(); ++i){
        playerScores_.at(i)->setText(QString::fromStdString(playerStats.at(i)));
        playerScores_.at(i)->setScale(1.2);
        playerScores_.at(i)->setPos(-600, (-380 + (static_cast<int>(i) * 40)));
        playerScores_.at(i)->setBrush(Qt::white);
    }
}

QPointF GameBoard::getHexXY(Common::CubeCoordinate hex)
{
    std::shared_ptr<HexPiece> targetHex = getHexPiece(hex);

    if(targetHex != nullptr){
        return targetHex->pos();
    }

    return QPointF(0.0, 0.0);
}

void GameBoard::moveGamePieceToXY(int pawnId, QPointF target)
{

    std::shared_ptr<GamePiece> pawn = getGamePiece(pawnId);

    if(pawn != nullptr){
        pawn->setPos(target);
    }
}

void GameBoard::closeEvent(QCloseEvent *event)
{
    if(gameBoardScene_ != nullptr){
        QList<QGraphicsItem *> itemsInScene = gameBoardScene_->items();
        for(int i = 0; i < itemsInScene.size(); ++i){
            gameBoardScene_->removeItem(itemsInScene.at(i));
        }
    }

    event->accept();
}

void GameBoard::showMainMenu()
{
    mainMenuScene_ = std::make_shared<MainMenu>(this);
    this->setScene(mainMenuScene_.get());
}

void GameBoard::setUpGameBoard()
{

    gameBoardScene_ = std::make_shared<QGraphicsScene>();
    gameBoardScene_->setBackgroundBrush(Qt::darkBlue);

    hintMessage_ = std::make_shared<QGraphicsSimpleTextItem>();
    gameBoardScene_->addItem(hintMessage_.get());

    for(unsigned int i = 0; i < players_.size(); ++i){
        std::shared_ptr<QGraphicsSimpleTextItem> playerScore = std::make_shared<QGraphicsSimpleTextItem>();
        gameBoardScene_->addItem(playerScore.get());
        playerScores_.push_back(playerScore);
    }

    gameRunner_ = std::make_shared<GameRunner>(players_, this);

    skipTurnButton_ = std::make_shared<ButtonGameBoard>(gameRunner_);
    skipTurnButton_->setText("Skip turn.");
    skipTurnButton_->setPos(350, 400);
    skipTurnButton_->setBrush(Qt::white);
    gameBoardScene_->addItem(skipTurnButton_.get());

    wheel_ = std::make_shared<Wheel>(gameRunner_);
    wheel_->setPos(-600, 150);
    gameBoardScene_->addItem(wheel_.get());

    wheelArrow_ = std::make_shared<ButtonMainMenu>("arrow_right", mainMenuScene_.get());
    wheelArrow_->setPos(-475, 190);
    wheelArrow_->setUnclickable();
    wheelArrow_->setRotation(-45);
    gameBoardScene_->addItem(wheelArrow_.get());


    int const SIDELENGHT = 48;
    int const BOARDWIDTH = 11; // must be odd. Coloring works for 11. done in hexpiece.cpp

    double movementX = qSqrt(3) * SIDELENGHT;
    double movementY = 1.5 * SIDELENGHT;

    int maxCoordValue = static_cast<int>((BOARDWIDTH - 1) / 2);
    int amountOfRows = static_cast<int>((BOARDWIDTH + 1) / 2);

    for(auto i = 0; i < amountOfRows; ++i){

        if(i == 0){ //Middle row
            for(auto j = 0; j < BOARDWIDTH; ++j){
                double screenX = ((-1 * ((BOARDWIDTH - 1) / 2)) * movementX) + (j * movementX);
                double screenY = i * movementY;

                int x = (-1 * maxCoordValue) + j;
                int y = maxCoordValue - j;
                int z = 0;

                auto hex = std::make_shared<HexPiece>(SIDELENGHT, gameRunner_);
                hex->setHexCoordinates(x, y, z);
                hex->setPos(screenX, screenY);
                gameBoardScene_->addItem(hex.get());
                hexPieces_.push_back(hex);
                addHex(hex);
            }
        }
        else{
            for(auto k = 0; k < BOARDWIDTH - i; ++k){ // Lower rows
                double screenX = ((-1 * ((BOARDWIDTH - 1) / 2)) * movementX) + (k * movementX) + (i * movementX / 2);
                double screenY = i * movementY;

                int x = (-1 * maxCoordValue) + k;
                int y = maxCoordValue - i - k;
                int z = i;

                auto hex = std::make_shared<HexPiece>(SIDELENGHT, gameRunner_);
                hex->setHexCoordinates(x, y, z);
                hex->setPos(screenX, screenY);
                gameBoardScene_->addItem(hex.get());
                hexPieces_.push_back(hex);
                addHex(hex);
                }

            for(auto l = 0; l < BOARDWIDTH - i; ++l){ // Upper Row
                double screenX = -1 * ((BOARDWIDTH - 1) / 2) * movementX + (l * movementX) + (i * movementX / 2);
                double screenY = -i * movementY;

                int x = (-1 * maxCoordValue + i) + l;
                int y = maxCoordValue - l;
                int z = -i;

                auto hex = std::make_shared<HexPiece>(SIDELENGHT, gameRunner_);
                hex->setHexCoordinates(x, y, z);
                hex->setPos(screenX, screenY);
                gameBoardScene_->addItem(hex.get());
                hexPieces_.push_back(hex);
                addHex(hex);
            }

        }
    }
}

void GameBoard::setUpPawns(int playerCount)
{
    int pawnId = 1;

    for(auto playerId = 1; playerId <= playerCount; ++playerId){
        for(size_t hexIndex = 0; hexIndex < hexPieces_.size(); ++hexIndex){
            Common::CubeCoordinate coord = hexPieces_.at(hexIndex)->getCoordinates();
            if(shouldThereBePawnHere(coord)){
                addPawn(playerId, pawnId, coord);
                ++pawnId;

            }
        }
    }
}

bool GameBoard::shouldThereBePawnHere(Common::CubeCoordinate pawnCoord)
{
    int randomFactor = rand() % 100;
    int x = abs(pawnCoord.x);
    int y = abs(pawnCoord.y);
    int z = abs(pawnCoord.z);

    std::shared_ptr<HexPiece> target = getHexPiece(pawnCoord);
    int targetOccupation = target->getPawnAmount();

    if(targetOccupation >= 3){
        return false;
    }
    else if((x + y + z) < 4 || (x + y + z) > 8)
        return false;

    else if(randomFactor < 50){
        return false;
    }
    else{
        return true;
    }
}

std::vector<double> GameBoard::getOffsets(int pawnsInTarget)
{
    std::vector<double> offsets;

    if(pawnsInTarget == 0){
        offsets.push_back(-7.0);
        offsets.push_back(-38.0);
    }
    else if(pawnsInTarget == 1){
        offsets.push_back(-7.0);
        offsets.push_back(-13.0);
    }

    else if(pawnsInTarget == 2){
        offsets.push_back(-45.0);
        offsets.push_back(-13.0);
    }

    else if(pawnsInTarget == 3){
        offsets.push_back(-45.0);
        offsets.push_back(-38.0);
    }
    else{
        offsets.push_back(0.0);
        offsets.push_back(0.0);
    }

    return offsets;
}

void GameBoard::cleanPawnPos(std::shared_ptr<HexPiece> hex)
{

    std::vector<std::shared_ptr<Common::Pawn>> pawns = hex->getPawns();

    for(unsigned int i = 0; i < pawns.size(); ++i){

        int pawnIdHex = pawns.at(i)->getId();

        for(unsigned int j = 0; j < gamePieces_.size(); ++j){
            int pawnId = gamePieces_.at(j)->getId();

            if (pawnIdHex == pawnId){
                std::vector<double> offsets =  getOffsets(static_cast<int>(i));
                double offsetX = offsets.at(0);
                double offsetY = offsets.at(1);

                double xCoordNew = hex->x() + offsetX;
                double yCoordNew = hex->y() + offsetY;

                gamePieces_.at(j)->setPos(xCoordNew, yCoordNew);
                break;
            }
        }
    }
}




