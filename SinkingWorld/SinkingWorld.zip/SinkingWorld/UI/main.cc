/* Software developed by Viktor Mykrä
 * Student number: 247391
 * @:viktor.mykra@student.tut.fi
 *
 * Game Sinking World 1.0
 */

#include "gameboard.hh"
#include <QApplication>

int main(int argc, char *argv[])
{

    QApplication a(argc, argv);
    GameBoard board;
    board.show();
    return a.exec();
}
