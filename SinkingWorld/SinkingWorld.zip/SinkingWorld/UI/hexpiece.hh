#ifndef HEXPIECE_HH
#define HEXPIECE_HH

#include "hex.hh"
#include <QGraphicsPolygonItem>
#include <QGraphicsSceneMouseEvent>

/* Impelents a hex that acts as an playingsurface for the game.
 */


class GameRunner;
class HexPiece : public QGraphicsPolygonItem, public Common::Hex
{
public:
    HexPiece(int sideLenght, std::shared_ptr<GameRunner> gameRunner);
    ~HexPiece() = default;

    void setHexCoordinates(int x, int y, int z);
    void sink();

protected:
    void mousePressEvent(QGraphicsSceneMouseEvent *event);
private:
    int sideLenght_;
    std::shared_ptr<GameRunner> gameRunner_;
    
    int x_;
    int y_;
    int z_;
    
    void setupHexGeometry();
    void setupHexColour();
};

#endif // HEXPIECE_HH
