#ifndef GAMEBOARD_HH
#define GAMEBOARD_HH

#include "igameboard.hh"
#include "mainmenu.hh"
#include "hexpiece.hh"
#include "gamepiece.hh"
#include "player.hh"
#include "gamerunner.hh"
#include "buttongameboard.hh"
#include "dolphinpiece.hh"
#include "boatpiece.hh"
#include "sharkpiece.hh"
#include "vortexpiece.hh"
#include "krakenpiece.hh"
#include "seamunsterpiece.hh"
#include "wheel.hh"


#include <memory>
#include <map>
#include <unordered_map>
#include <QGraphicsView>
#include <QGraphicsSimpleTextItem>
#include <QGraphicsPolygonItem>
#include <vector>

/* MainWindow and graphical implementation for the game.
 * Creates assets on gameboard and handles moving them around.
 */


class GameBoard : public QGraphicsView, public Common::IGameBoard
{
    Q_OBJECT
public:
    GameBoard();
    ~GameBoard()=default;
    int checkTileOccupation(Common::CubeCoordinate tileCoord) const;
    bool isWaterTile(Common::CubeCoordinate tileCoord) const;
    
    std::shared_ptr<Common::Hex> getHex(Common::CubeCoordinate hexCoord) const;
    std::shared_ptr<HexPiece> getHexPiece(Common::CubeCoordinate hexCoord) const;
    std::shared_ptr<GamePiece> getGamePiece(int pawnId) const;
    std::shared_ptr<Common::Transport> getTransport(int id) const;
    std::shared_ptr<Common::Actor> getActor(int id) const;
    
    void addPawn(int playerId, int pawnId);
    void addPawn(int playerId, int pawnId, Common::CubeCoordinate coord);
    void movePawn(int pawnId, Common::CubeCoordinate pawnCoord);
    void removePawn(int pawnId);

    void createActor(std::string type, Common::CubeCoordinate hex);
    void addActor(std::shared_ptr<Common::Actor> actor, Common::CubeCoordinate actorCoord);
    void moveActor(int actorId, Common::CubeCoordinate actorCoord);
    void removeActor(int actorId);

    void addHex(std::shared_ptr<Common::Hex> newHex);

    void createTransport(std::string type, Common::CubeCoordinate hex);
    void addTransport(std::shared_ptr<Common::Transport> transport, Common::CubeCoordinate coord);
    void moveTransport(int id, Common::CubeCoordinate coord);
    void removeTransport(int id);

    void startNewGame();
    bool isGameOver();
    void finishGame();
    void setHint(std::string message);
    void setScoreBoard(std::vector<std::string> playerStats);

    QPointF getHexXY(Common::CubeCoordinate hex);
    void moveGamePieceToXY(int pawnId, QPointF target);

    void closeEvent(QCloseEvent* event);

    // Moves pawns in hex to always be in right place
    void cleanPawnPos(std::shared_ptr<HexPiece> hex);

private:
    std::shared_ptr<MainMenu> mainMenuScene_;
    void showMainMenu();

    std::shared_ptr<GameRunner> gameRunner_ = nullptr;
    std::shared_ptr<QGraphicsScene> gameBoardScene_ = nullptr;
    void setUpGameBoard();
    void setUpPawns(int playerCount);

    // RAndomizes pawns on gameboard
    bool shouldThereBePawnHere(Common::CubeCoordinate pawnCoord);

    // at(0) = x off set at(1) = y offset
    std::vector<double> getOffsets(int pawnsInTarget);




    std::vector<std::shared_ptr<Common::Hex>> hexPiecesCommon_;
    std::vector<std::shared_ptr<HexPiece>> hexPieces_;

    std::vector<std::shared_ptr<GamePiece>> gamePieces_;

    std::vector<std::shared_ptr<Common::Transport>> transports_;
    std::vector<std::shared_ptr<Common::Actor>> actors_;

    std::vector<std::shared_ptr<Player>> players_;

    std::shared_ptr<QGraphicsSimpleTextItem> hintMessage_ = nullptr;
    std::vector<std::shared_ptr<QGraphicsSimpleTextItem>> playerScores_;

    std::shared_ptr<ButtonGameBoard> skipTurnButton_ = nullptr;
    std::shared_ptr<Wheel> wheel_ = nullptr;
    std::shared_ptr<ButtonMainMenu> wheelArrow_ = nullptr;

};
#endif // GAMEBOARD_HH
