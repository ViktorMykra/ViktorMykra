#ifndef WHEEL_HH
#define WHEEL_HH

#include <QObject>
#include <QGraphicsPixmapItem>
#include <QPropertyAnimation>
#include <string>
#include <memory>

/* Impelents a spinwheel on the gameboard.
 * spinwheel is used as a part of the game.
 */

class GameRunner;

class Wheel : public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT
    Q_PROPERTY(qreal rotation READ rotation WRITE setRotation)

public:
    Wheel(std::shared_ptr<GameRunner> gameRunner);
    ~Wheel()=default;

protected:
    void mousePressEvent(QGraphicsSceneMouseEvent *event);

private slots: 
    void animationFinished();

private:
    std::shared_ptr<GameRunner> gameRunner_;
    std::pair<std::string, std::string> spinWheel();
    QPropertyAnimation* spinningAnimation_;
    std::string spinResult_;
};

#endif // WHEEL_HH
