#include "buttongameboard.hh"
#include "gamerunner.hh"

ButtonGameBoard::ButtonGameBoard(std::shared_ptr<GameRunner> gameRunner):
    gameRunner_(gameRunner)
{}

void ButtonGameBoard::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    gameRunner_->skipTurn();
    event->accept();
}
