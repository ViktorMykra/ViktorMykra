#include "vortexpiece.hh"
#include "gameboard.hh"
#include "gamerunner.hh"

VortexPiece::VortexPiece(int id, std::shared_ptr<GameRunner> gameRunner, GameBoard* gameBoard) :
    id_(id),
    gameRunner_(gameRunner),
    gameBoard_(gameBoard)
{
    this->setToolTip(QString("Vortex, distroys boats."));
    this->setPixmap(QPixmap(QString(":/images/buttonimages/vortex.png")));
    this->setScale(2);
    this->setTransformOriginPoint(25,25);
    this->setZValue(0);

    rotationAnimation_ = new QPropertyAnimation(this, "rotation");
    connect(rotationAnimation_, SIGNAL(finished()), this, SLOT(animationFinished()));
}

void VortexPiece::move(std::shared_ptr<Common::Hex> to)
{
    QPointF target = gameBoard_->getHexXY(to->getCoordinates());
    qreal targetX = target.rx() - 20.0;
    qreal targetY = target.ry() - 25.0;
    this->setPos(QPointF(targetX, targetY));

    rotationAnimation();

    addHex(to);
}

void VortexPiece::doAction()
{
    std::vector<Common::CubeCoordinate> adjacentCoordinates = getHex()->getNeighbourVector();

    for(unsigned int i = 0; i < adjacentCoordinates.size(); ++i){

        std::shared_ptr<Common::Hex> hex = gameBoard_->getHex(adjacentCoordinates.at(i));

        if(hex->getPieceType() == "Water"){
            std::vector<std::shared_ptr<Common::Pawn>> pawns = hex->getPawns();
            std::vector<std::shared_ptr<Common::Transport>> transports = hex->getTransports();
            std::vector<std::shared_ptr<Common::Actor>> actors = hex->getActors();

            if(pawns.size() > 0){
                for(unsigned int j = 0; j < pawns.size(); ++j){
                    int pawnId = pawns.at(j)->getId();
                    gameBoard_->removePawn(pawnId);
                }
            }

            if(transports.size() > 0){
                for(unsigned int k = 0; k < transports.size(); ++k){

                    int transId = transports.at(k)->getId();
                    std::vector<std::shared_ptr<Common::Pawn>> pawnsOnTrans = transports.at(k)->getPawnsInTransport();

                    for(unsigned int l = 0; l < pawnsOnTrans.size(); ++l){
                        gameBoard_->removePawn(pawnsOnTrans.at(l)->getId());
                    }
                    gameBoard_->removeTransport(transId);
                }
            }
            if(actors.size() > 0){
                for(unsigned int m = 0; m < actors.size(); ++m){
                    int actorId = actors.at(m)->getId();
                    gameBoard_->removeActor(actorId);
                }
            }
        }
    }

    std::vector<std::shared_ptr<Common::Pawn>> pawns = getHex()->getPawns();
    for(unsigned int i = 0; i < pawns.size(); ++i){
        int pawnId = pawns.at(i)->getId();

        gameBoard_->removePawn(pawnId);
    }
    gameBoard_->removeActor(getId());
}

std::string VortexPiece::getActorType() const
{
    return "vortex";
}

int VortexPiece::getId() const
{
    return id_;
}

void VortexPiece::addHex(std::shared_ptr<Common::Hex> hex)
{
    hex1_ = hex;
}

std::shared_ptr<Common::Hex> VortexPiece::getHex()
{
    return hex1_;
}

void VortexPiece::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    event->accept();
    gameRunner_->actorPress(shared_from_this());
}

void VortexPiece::animationFinished()
{
    doAction();
}

void VortexPiece::rotationAnimation()
{
    rotationAnimation_->setDuration(800);
    rotationAnimation_->setStartValue(this->rotation());
    rotationAnimation_->setEndValue(360.0);
    rotationAnimation_->start();

}

