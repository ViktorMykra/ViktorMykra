#include "hexpiece.hh"

#include "gamerunner.hh"
#include <QtMath>
#include <QPolygon>
#include <QPainter>
#include <QPen>

HexPiece::HexPiece(int sideLenght, std::shared_ptr<GameRunner> gameRunner):
    sideLenght_(sideLenght),
    gameRunner_(gameRunner)
{
    this->setZValue(-2);
    setupHexGeometry();
}

void HexPiece::setHexCoordinates(int x, int y, int z)
{
    x_ = x;
    y_ = y;
    z_ = z;

    setCoordinates(Common::CubeCoordinate(x_, y_, z_));
    setupHexColour();
}

void HexPiece::sink()
{
    this->setPieceType("Water");
    this->setZValue(-5);
    this->setBrush(Qt::blue);
}

void HexPiece::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    gameRunner_->hexPress(shared_from_this());
    event->accept();
}

void HexPiece::setupHexGeometry()
{
    //Shape
    QPolygonF polygon;

    double dx = qSqrt(3)/2 * sideLenght_;

    polygon << QPointF(dx, -sideLenght_/2)
            << QPointF(0, -sideLenght_)
            << QPointF(-dx, -sideLenght_/2)
            << QPointF(-dx, sideLenght_/2)
            << QPointF(0, sideLenght_)
            << QPointF(dx, sideLenght_/2);

    this->setPolygon(polygon);
}

void HexPiece::setupHexColour()
{


    QPen pen;
    pen.setWidth(1);
    pen.setColor(Qt::black);
    this->setPen(pen);

    if((x_ == 0) and (y_ == 0) and (z_ == 0)){
        this->setBrush(Qt::darkGray);
    }
    else if((std::abs(x_) +  std::abs(y_) + std::abs(z_)) == 2){
        this->setBrush(Qt::gray);
    }
    else if((std::abs(x_) +  std::abs(y_) + std::abs(z_)) == 4){
        this->setBrush(Qt::darkGreen);
    }
    else if(std::abs(x_) +  std::abs(y_) + std::abs(z_) == 6 or
            std::abs(x_) +  std::abs(y_) + std::abs(z_) == 8){
        this->setBrush(Qt::darkYellow);
    }
    else{
        this->setBrush(Qt::blue);
        this->setZValue(-5);
        this->setPieceType("Water");
    }
}




