#include "sharkpiece.hh"
#include "gameboard.hh"
#include "gamerunner.hh"

SharkPiece::SharkPiece(int id, std::shared_ptr<GameRunner> gameRunner, GameBoard* gameBoard) :
    id_(id),
    gameRunner_(gameRunner),
    gameBoard_(gameBoard)
{
    this->setToolTip(QString("Shark, eats pawns."));
    this->setPixmap(QPixmap(QString(":/images/buttonimages/shark.png")));

    movementAnimation_ = new QPropertyAnimation(this, "pos");

    this->setScale(0.4);
    this->setZValue(-4);
    
    connect(movementAnimation_, SIGNAL(finished()), this, SLOT(animationFinished()));
}


void SharkPiece::move(std::shared_ptr<Common::Hex> to)
{
    if(hex1_ != nullptr){
        hex1_->removeActor(shared_from_this());
    }

    QPointF target = gameBoard_->getHexXY(to->getCoordinates());
    qreal targetX = target.rx()-10;
    qreal targetY = target.ry()-20;
    movementAnimation(QPointF(targetX, targetY));
    to->addActor(shared_from_this());
    addHex(to);

}

void SharkPiece::doAction()
{
    //getHex()->clearPawnsFromTerrain();

    std::vector<std::shared_ptr<Common::Pawn>> pawns = getHex()->getPawns();
    for(unsigned int i = 0; i < pawns.size(); ++i){
        int pawnId = pawns.at(i)->getId();
        std::shared_ptr<GamePiece> pawn = gameBoard_->getGamePiece(pawnId);

        if(!(pawn->isOnTransport())){
            gameBoard_->removePawn(pawnId);
        }
    }
}

std::string SharkPiece::getActorType() const
{
    return "shark";
}

int SharkPiece::getId() const
{
    return id_;
}

void SharkPiece::addHex(std::shared_ptr<Common::Hex> hex)
{
    hex1_ = hex;
}

std::shared_ptr<Common::Hex> SharkPiece::getHex()
{
    return hex1_;
}

void SharkPiece::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    event->accept();
    gameRunner_->actorPress(shared_from_this());
}

void SharkPiece::animationFinished()
{
    doAction();
}

void SharkPiece::movementAnimation(QPointF target)
{ 
    movementAnimation_->setDuration(450);
    movementAnimation_->setStartValue(this->pos());
    movementAnimation_->setEndValue(target);
    movementAnimation_->start();
    
}
