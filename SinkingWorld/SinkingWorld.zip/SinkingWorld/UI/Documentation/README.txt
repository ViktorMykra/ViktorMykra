This is a student project for the Ohjelmointi 3 course in TTY in fall of 2018.
Programming was done mainly by Viktor Mykrä. Some effort was done by Anna Virtanen
who later dropped out of the course. This project does not completely adhere to spec gicen by the course.
This is mainly because of the time limitations introduced by the fact that I was working alone for great majority of this project.

Things to note:

    -GameBoard class does not pass the tests that were handed down by the course.
     I did write rudimentary tests for GameState class and redacted Gameboard tests from the project.

    -In Main menu there is viewport for highscores but I did not have enought time to implement highscore system.
     This is declared in highscores view.

    -Help for playing the game can be found in Help view in main menu.

    -My code is not doing too well under SonarCubes scrutiny. I fully realize that and also understand the implications.
     Main reason for this is amount of work that had to be done in a short period of time. Working on this project alone
     meant that there was 1/2 time for everything and I acknowledge it affected the quality of the code.
     I still tried to create a fully functional game that adheres to the specs given by the course.

    -Also the documentation is pretty rudimentary because of running out of time.

Implemented "additional features":
    -Animated pawn, actor and transport movement.
    -Visualised wheel as a part of the game.
    -Animated wheel spinning as a part of the game.

Playing the game:

    This is a board game called Sinking World.
    Main goal of the game is to get all your pawns
    to the center piece of the gameboard. Game happens in 3 phases.

    Important:

    If at some point game seemingly wont let you do any action you can always skip your turn with the skip turn button.
    Mainly this is a problem if you only have pawns in water and < 2 moves or there is no actors on board and game is in spinnig phase.

    Movement:
        -Cant move trough ar to full hex( 3 pawns)

        -Cant move further than your actions left

        -Moving in water takes 3 actions.

        -Pawn can board and unboard a vessel while moving
            -this uses 1 action point.

        -Board the vessel by selecting a pawn and a clicking
         the vessel in the same hex.

        -Move the pawn by selecting a pawn and clicking
         the hex you want to move to.

         -Also vessels can be moved while in Movement phase.
         Select vessel you want to move and click water hex you want it to move to.
               -To move a vessel you need to have over 50% of your pawns on
                the vessel.
    Sinking:
        -Player can choose to sink a hex

        -This will turn the hex to a water tile

        -Actor or vessel will appear.
    Spinning:
        -Player chooses one actor or vessel on the board
         and spins the wheel. Wheel tells how far you can move.

        -To move a vessel you need to have over 50% of your pawns on
         the vessel.

    Game end when there is no more pawns on the gameboard.




Kind Regards:

Viktor Mykrä
student Number: 274391
@: viktor.mykra@student.tut.fi

19/12/2018, Tampere
