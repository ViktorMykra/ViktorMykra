#ifndef BUTTONGAMEBOARD_HH
#define BUTTONGAMEBOARD_HH

#include <QGraphicsSimpleTextItem>
#include <memory>

/* Implements a button for skipping a turn in gameboard.
 * Used when no other viable moves are left to be done.
 */

class GameRunner;
class ButtonGameBoard : public QGraphicsSimpleTextItem
{
public:
    ButtonGameBoard(std::shared_ptr<GameRunner> gameRunner);
protected:
    void mousePressEvent(QGraphicsSceneMouseEvent *event);
private:
    std::shared_ptr<GameRunner> gameRunner_;
};

#endif // BUTTONGAMEBOARD_HH
