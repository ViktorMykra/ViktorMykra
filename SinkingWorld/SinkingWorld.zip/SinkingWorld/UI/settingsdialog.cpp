#include "settingsdialog.hh"

SettingsDialog::SettingsDialog(int playercount,
    std::string player1, std::string player2, std::string player3, std::string player4) :
    players(playercount),
    namePlayer1(QString::fromStdString(player1)),
    namePlayer2(QString::fromStdString(player2)),
    namePlayer3(QString::fromStdString(player3)),
    namePlayer4(QString::fromStdString(player4))
{
    this->setWindowTitle("Settings");
    this->setModal(1);

    if(players < 1 or players > 4){
        players = 1;
    }

    setupLayout();

    connect(okButton_, SIGNAL(clicked(bool)), this, SLOT(okButtonPress()));  
    connect(playersSpinBox_, SIGNAL(valueChanged(int)), this,
            SLOT(playerCountChanged()));
    connect(player1NameLineEdit_, SIGNAL(editingFinished()), this,
            SLOT(player1NameChanged()));
    connect(player2NameLineEdit_, SIGNAL(editingFinished()), this,
            SLOT(player2NameChanged()));
    connect(player3NameLineEdit_, SIGNAL(editingFinished()), this,
            SLOT(player3NameChanged()));
    connect(player4NameLineEdit_, SIGNAL(editingFinished()), this,
            SLOT(player4NameChanged()));
}

SettingsDialog::~SettingsDialog()
{
    releaseAssets();
}

std::string SettingsDialog::getPlayer1Name()
{
    return namePlayer1.toStdString();
}

std::string SettingsDialog::getPlayer2Name()
{
    return namePlayer2.toStdString();
}

std::string SettingsDialog::getPlayer3Name()
{
    return namePlayer3.toStdString();
}

std::string SettingsDialog::getPlayer4Name()
{
    return namePlayer4.toStdString();
}

void SettingsDialog::okButtonPress()
{
    players = playersSpinBox_->value();
    namePlayer1 = player1NameLineEdit_->text();
    namePlayer2 = player2NameLineEdit_->text();
    namePlayer3 = player3NameLineEdit_->text();
    namePlayer4 = player4NameLineEdit_->text();

    close();
}

void SettingsDialog::playerCountChanged()
{
    if(playersSpinBox_->value() == 1){
        player2NameLineEdit_->setDisabled(1);
        player3NameLineEdit_->setDisabled(1);
        player4NameLineEdit_->setDisabled(1);
    }

    if(playersSpinBox_->value() == 2){
        player2NameLineEdit_->setEnabled(1);
        player3NameLineEdit_->setDisabled(1);
        player4NameLineEdit_->setDisabled(1);
    }
    if(playersSpinBox_->value() == 3){
        player2NameLineEdit_->setEnabled(1);
        player3NameLineEdit_->setEnabled(1);
        player4NameLineEdit_->setDisabled(1);
    }
    if(playersSpinBox_->value() == 4){
        player2NameLineEdit_->setEnabled(1);
        player3NameLineEdit_->setEnabled(1);
        player4NameLineEdit_->setEnabled(1);
    }


}

void SettingsDialog::player1NameChanged()
{
    if(player1NameLineEdit_->text() == ""){
        player1NameLineEdit_->setText("Player 1");
    }
}
void SettingsDialog::player2NameChanged()
{
    if(player2NameLineEdit_->text() == ""){
        player2NameLineEdit_->setText("Player 2");
    }
}
void SettingsDialog::player3NameChanged()
{
    if(player3NameLineEdit_->text() == ""){
        player3NameLineEdit_->setText("Player 3");
    }
}
void SettingsDialog::player4NameChanged()
{
    if(player4NameLineEdit_->text() == ""){
        player4NameLineEdit_->setText("Player 4");
    }
}

void SettingsDialog::setupLayout()
{
    okButton_ = new QPushButton("OK", this);

    playersSpinBox_ = new QSpinBox();
    playersSpinBox_->setValue(players);
    playersSpinBox_->setMaximum(4);
    playersSpinBox_->setMinimum(1);

    player1NameLineEdit_ = new QLineEdit();
    player1NameLineEdit_->setMaxLength(10);
    player1NameLineEdit_->setText(namePlayer1);

    player2NameLineEdit_ = new QLineEdit();
    player2NameLineEdit_->setMaxLength(10);
    player2NameLineEdit_->setText(namePlayer2);

    player3NameLineEdit_ = new QLineEdit();
    player3NameLineEdit_->setMaxLength(10);
    player3NameLineEdit_->setText(namePlayer3);

    player4NameLineEdit_ = new QLineEdit();
    player4NameLineEdit_->setMaxLength(10);
    player4NameLineEdit_->setText(namePlayer4);

    if(players == 1){
        player2NameLineEdit_->setDisabled(1);
        player3NameLineEdit_->setDisabled(1);
        player4NameLineEdit_->setDisabled(1);
    }

    formLayout_ = new QFormLayout();

    formLayout_->addRow(tr("Players (1-4): "), playersSpinBox_);
    formLayout_->addRow(tr("Player 1 name: "), player1NameLineEdit_);
    formLayout_->addRow(tr("Player 2 name: "), player2NameLineEdit_);
    formLayout_->addRow(tr("Player 3 name: "), player3NameLineEdit_);
    formLayout_->addRow(tr("Player 4 name: "), player4NameLineEdit_);

    gridLayout_ = new QGridLayout();
    gridLayout_->addLayout(formLayout_, 0, 0);
    gridLayout_->addWidget(okButton_, 1, 0);

    this->setLayout(gridLayout_);

}

void SettingsDialog::releaseAssets()
{
    delete okButton_;
    delete player1NameLineEdit_;
    delete player2NameLineEdit_;
    delete playersSpinBox_;
    delete formLayout_;
    delete gridLayout_;
}
