#include "wheel.hh"
#include "gamerunner.hh"

Wheel::Wheel(std::shared_ptr<GameRunner> gameRunner):
    gameRunner_(gameRunner)
{
    QString imagePath(":/images/buttonimages/wheel.png");
    this->setPixmap(QPixmap(imagePath));
    this->setTransformOriginPoint(100,100);
    this->setScale(0.7);
    this->setZValue(-4);

    spinningAnimation_ = new QPropertyAnimation(this, "rotation");
    spinningAnimation_->setDuration(500);

    connect(spinningAnimation_, SIGNAL(finished()), this, SLOT(animationFinished()));
}

void Wheel::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    event->accept();

    if((gameRunner_->readyForWheel()) && spinningAnimation_->state() != spinningAnimation_->Running){
        int randomSeed = (rand() % 4) + 1;
        setRotation(0);
        qreal rotationNeeded = 720; // always spin atleas 3 rounds

        if(randomSeed == 1){
            spinResult_ = "1";
            rotationNeeded += 1 * 90;
        }
        else if(randomSeed == 2){
            spinResult_ = "D";
            rotationNeeded += 2 * 90;
        }
        else if(randomSeed == 3){
            spinResult_ = "3";
            rotationNeeded += 3 * 90;
        }
        else{ // 4
            spinResult_ = "2";
            rotationNeeded += 4 * 90;
        }
        spinningAnimation_->setStartValue(rotation());
        spinningAnimation_->setEndValue(rotationNeeded);
        spinningAnimation_->start();

    }
}

void Wheel::animationFinished()
{
    gameRunner_->wheelPress(spinResult_);
}
