#include "gamerunner.hh"
#include "gameboard.hh"

#define UNUSED(x) (void)(x)

GameRunner::GameRunner(std::vector<std::shared_ptr<Player>> players, GameBoard* gameBoard) :
    players_(players),
    gameBoard_(gameBoard)
{
    gameState_ = std::make_shared<GameState>();
    playerCount_ = static_cast<unsigned int>(players_.size());
    getCurrentPlayer()->setActionsLeft(3);
    updateHintText();
    updateScoreBoard();
}

int GameRunner::movePawn(Common::CubeCoordinate origin, Common::CubeCoordinate target, int pawnId)
{
    int movesLeft = checkPawnMovement(origin, target, pawnId);

    if(movesLeft != -1){
        gameBoard_->movePawn(pawnId, target);
        return movesLeft;
    }
    else{
        return static_cast<int>(getCurrentPlayer()->getActionsLeft());
    }
}

void GameRunner::moveActor(Common::CubeCoordinate origin, Common::CubeCoordinate target, int actorId, std::string moves)
{
    UNUSED(origin);
    UNUSED(moves);
    gameBoard_->moveActor(actorId, target);
}

int GameRunner::moveTransport(Common::CubeCoordinate origin, Common::CubeCoordinate target, int transportId)
{
    std::string moves = std::to_string(getCurrentPlayer()->getActionsLeft());
    int movesLeft = checkTransportMovement(origin, target, transportId, moves);

    if(movesLeft != -1){
        gameBoard_->moveTransport(transportId, target);
        return movesLeft;
    }
    else{
        return static_cast<int>(getCurrentPlayer()->getActionsLeft());
    }
}

int GameRunner::moveTransportWithSpinner(Common::CubeCoordinate origin, Common::CubeCoordinate target, int transportId, std::string moves)
{
    int movesLeft = checkTransportMovement(origin, target, transportId, moves);

    if(movesLeft != -1){
        gameBoard_->moveTransport(transportId, target);
        return 1;
    }
    else{
        return 0;
    }
}

int GameRunner::checkPawnMovement(Common::CubeCoordinate origin, Common::CubeCoordinate target, int pawnId)
{
    int targetOccupation;
    int movesLeft = static_cast<int>(getCurrentPlayer()->getActionsLeft());
    int distance = calculateDistance(origin, target);

    std::shared_ptr<HexPiece> originHex = gameBoard_->getHexPiece(origin);
    std::shared_ptr<HexPiece> targetHex = gameBoard_->getHexPiece(target);
    std::shared_ptr<GamePiece> movingPawn = gameBoard_->getGamePiece(pawnId);

    if((originHex == nullptr) || targetHex == nullptr){
        return -1;
    }

    if((originHex->getPieceType() == "Water") && (targetHex->getPieceType() == "Water")){
        distance = distance * 3;
    }

    targetOccupation = targetHex->getPawnAmount();

    if(targetOccupation >= 3){
        gameBoard_->setHint("Illegal move: Target hex is full!");
        return -1;
    }
    if((distance == 0) && !(movingPawn->isOnTransport())){
        gameBoard_->setHint("Illegal move: You're already in that hex!");
        return -1;
    }
    if(distance > movesLeft){
        gameBoard_->setHint("Illegal move: Not nough moves left!");
        return -1;
    }

    // Get hexes on the route
    std::vector<Common::CubeCoordinate> routeHexes = getRouteHexes(origin, target);

    // Check hexes on the route
    for(unsigned int i = 0; i < routeHexes.size(); ++i){
        std::shared_ptr<HexPiece> hexInRoute = gameBoard_->getHexPiece(routeHexes.at(i));

        // Not all coordinates are valid, check that.
        if(hexInRoute != nullptr){
            int pawnsInHexInRoute = hexInRoute->getPawnAmount();

            if(pawnsInHexInRoute >= 3){
                gameBoard_->setHint("Illegal move: You cant move trough full hex.");
                return -1;
            }
        }
    }

    return movesLeft - distance;

}

bool GameRunner::checkActorMovement(Common::CubeCoordinate origin, Common::CubeCoordinate target, int actorId, std::string moves)
{
    UNUSED(actorId);

    int movesLeft;
    int distance;
    std::shared_ptr<Common::Hex> targetHex = gameBoard_->getHex(target);

    if(moves == "1"){
        movesLeft = 1;
    }
    else if(moves == "2"){
        movesLeft = 2;
    }
    else if(moves == "3"){
        movesLeft = 3;
    }
    else if(moves == "D"){
        movesLeft = -1;
    }
    else{
        return false;
    }

    if(targetHex->getPieceType() != "Water"){
        gameBoard_->setHint("Illegal move: You cant move to groung hex.");
        return false;
    }
    if(targetHex->getActors().size() > 0){
        gameBoard_->setHint("Illegal move: There is already actor in that hex.");
        return false;
    }

    distance = calculateDistance(origin, target);
    if((movesLeft != -1) && (distance > movesLeft)){
        gameBoard_->setHint("Illegal move: Not enough moves left.");
        return false;
    }
    return true;
}

int GameRunner::checkTransportMovement(Common::CubeCoordinate origin, Common::CubeCoordinate target, int transportId, std::string moves)
{
    int movesLeft;
    int distance;
    int currentPlayerId;
    std::shared_ptr<Common::Transport> movingTransport = gameBoard_->getTransport(transportId);
    std::shared_ptr<Common::Hex> originHex = gameBoard_->getHex(origin);
    std::shared_ptr<Common::Hex> targetHex = gameBoard_->getHex(target);

    if(moves == "1"){
        movesLeft = 1;
    }
    else if(moves == "2"){
        movesLeft = 2;
    }
    else if(moves == "3"){
        movesLeft = 3;
    }
    else if(moves == "D"){
        movesLeft = -1;
    }
    else{
        return -1;
    }

    if((movingTransport == nullptr) || (originHex == nullptr) || (targetHex == nullptr)){
        return -1;
    }
    if(!(movingTransport->getHex() == originHex)){
        gameBoard_->setHint("Illegal move: Transport is already in that hex.");
        return -1;
    }
    if(targetHex->getPieceType() != "Water"){
        gameBoard_->setHint("Illegal move: You cant move to groung hex.");
        return -1;
    }
    if((movingTransport->getPawnsInTransport().size() != 0) && (movesLeft == -1)){
        gameBoard_->setHint("Illegal move: You cant dive with pawns onboard.");
        return -1;
    }
    distance = calculateDistance(origin, target);

    if((movesLeft != -1) && (distance > movesLeft)){
        gameBoard_->setHint("Illegal move: Not enough moves left.");
        return -1;
    }

    currentPlayerId = currentPlayer();

    if(!(movingTransport->canMove(currentPlayerId))){
        gameBoard_->setHint("Illegal move: Not enough your pawns on board.");
        return -1;
    }
    if(targetHex->getTransports().size() != 0){
        gameBoard_->setHint("Illegal move: Theres already a vessel on that hex.");
        return -1;
    }

    if((currentGamePhase() == Common::SPINNING) && (movesLeft == -1)){
        return 0;
    }
    if((currentGamePhase() == Common::SPINNING) && (movesLeft <= distance)){
        return 0;
    }
    if((currentGamePhase() == Common::MOVEMENT) && (movesLeft >= distance)){
        return movesLeft - distance;
    }
    return -1;
}

std::string GameRunner::flipTile(Common::CubeCoordinate tileCoord)
{
    std::shared_ptr<HexPiece> hexToSink = gameBoard_->getHexPiece(tileCoord);
    std::vector<Common::CubeCoordinate> neighbours = hexToSink->getNeighbourVector();
    int waterNeighbours = 0;

    for(unsigned int i = 0; i < neighbours.size(); ++i){
        std::shared_ptr<HexPiece> neighbour = gameBoard_->getHexPiece(neighbours.at(i));
        if(neighbour->getPieceType() == "Water"){
            waterNeighbours += 1;
        }
    }

    Common::CubeCoordinate origo = Common::CubeCoordinate(0,0,0);

    if((waterNeighbours >= 2) && !(tileCoord == origo)){

        std::vector<std::string> actorsNtransports{"shark", "dolphin", "boat", "shark", "vortex", "seamunster", "kraken"};
        hexToSink->sink();

        int randomIndex = rand() % static_cast<int>(actorsNtransports.size());
        return actorsNtransports.at(static_cast<size_t>(randomIndex));
    }
     return "";
}

std::pair<std::string, std::string> GameRunner::spinWheel()
{
    return std::pair<std::string, std::string>();
}

Common::SpinnerLayout GameRunner::getSpinnerLayout() const
{
    return Common::SpinnerLayout();
}

std::shared_ptr<Common::IPlayer> GameRunner::getCurrentPlayer()
{
    int currentPlayerId = currentPlayer();
    for(unsigned int i = 0; i < players_.size(); ++i){
        int playerId = players_.at(i)->getPlayerId();
        if(currentPlayerId == playerId){
            return players_.at(i);
        }
    }
    return nullptr;
}

int GameRunner::currentPlayer() const
{
    return gameState_->currentPlayer();
}

int GameRunner::playerAmount() const
{
    return static_cast<int>(playerCount_);
}

Common::GamePhase GameRunner::currentGamePhase() const
{
    return gameState_->currentGamePhase();
}

int GameRunner::calculateDistance(Common::CubeCoordinate origin, Common::CubeCoordinate target)
{
    int distance = (abs(origin.x - target.x) + abs(origin.y - target.y) + abs(origin.z - target.z)) / 2;
    return distance;
}

Common::CubeCoordinate GameRunner::cube_lerp(Common::CubeCoordinate origin, Common::CubeCoordinate target, double k)
{
    int newX = lerp(origin.x, target.x, k);
    int newY = lerp(origin.y, target.y, k);
    int newZ = lerp(origin.z, target.z, k);
    return Common::CubeCoordinate(newX, newY, newZ);
}

int GameRunner::lerp(int a, int b, double k)
{
    double value = (a + (b - a) * k);
    int integer = static_cast<int>(value);
    return integer;
}

std::vector<Common::CubeCoordinate> GameRunner::getRouteHexes(Common::CubeCoordinate origin, Common::CubeCoordinate target)
{

    int distance = calculateDistance(origin, target);
    std::vector<Common::CubeCoordinate> hexesInRoute;

    for(int i = 1; i < distance; ++i){
        double k = ((1.0 / distance) * i);
        Common::CubeCoordinate newCoord = cube_lerp(origin, target, k);
        hexesInRoute.push_back(newCoord);
    }

    return hexesInRoute;
}



void GameRunner::gamePiecePress(std::shared_ptr<Common::Pawn> pressedPiece)
{
    int ownerId = pressedPiece->getPlayerId();
    int pressedPieceId = pressedPiece->getId();

    if(currentGamePhase() == Common::MOVEMENT){

        if(selectedPawnId_ != -1){ // UnHighlight previous selected pawn.
            std::shared_ptr<GamePiece> selectedPawn = gameBoard_->getGamePiece(selectedPawnId_);
            if(selectedPawn != nullptr){
                selectedPawn->setScale(0.4);
            }
        }

        if(ownerId == currentPlayer()){ // If player clicked own pawn take id and highlight;
            selectedPawnId_ = pressedPieceId;
            selectedTransportId_ = -1; // No transport can be selected at the same time.
            std::shared_ptr<GamePiece> newSelectedPawn= gameBoard_->getGamePiece(selectedPawnId_);
            newSelectedPawn->setScale(0.6);
        }

    }

    if(currentGamePhase() == Common::SINKING){

    }
    if(currentGamePhase() == Common::SPINNING){

    }
}

void GameRunner::hexPress(std::shared_ptr<Common::Hex> pressedHex)
{
    Common::CubeCoordinate const pressedHexCoord = pressedHex->getCoordinates();
    std::shared_ptr<GamePiece> const selectedPiece = gameBoard_->getGamePiece(selectedPawnId_);
    std::shared_ptr<Common::Transport> const selectedTransport = gameBoard_->getTransport(selectedTransportId_);
    std::shared_ptr<Common::Actor> const selectedActor = gameBoard_->getActor(selectedActorId_);
    unsigned int actionsLeft = getCurrentPlayer()->getActionsLeft();

    if(currentGamePhase() == Common::MOVEMENT){

        if((selectedPawnId_ != -1) && (selectedPiece != nullptr)){ // selected pawn -> hex press

            Common::CubeCoordinate selectedPieceCoord = selectedPiece->getCoordinates();

            if((selectedPiece->isOnTransport()) && !(selectedPieceCoord == pressedHexCoord)){ //Moving from vessel to other hex.

                selectedPiece->setScale(0.4);
                gameBoard_->setHint("Unboard transporter firts.");
                return;

            }

            else if((selectedPiece->isOnTransport()) && (selectedPieceCoord == pressedHexCoord) && (actionsLeft > 0) ){ //Unboarding vessel

                if(pressedHex->getPawnAmount() < 3){

                    std::shared_ptr<Common::Transport> transporter = gameBoard_->getTransport(selectedPiece->getTransportId());

                    selectedPiece->setScale((0.4));

                    transporter->removePawn(selectedPiece);

                    selectedPiece->unboardTransport();

                    gameBoard_->movePawn(selectedPawnId_, pressedHexCoord);

                    selectedPawnId_ = -1;
                    selectedTransportId_ = -1;

                    useActions(1);

                }
                else{
                    gameBoard_->setHint("This hex is full.");
                }

                return;
            }
            else{ // Moving pawn

                Common::CubeCoordinate originCoord = selectedPiece->getCoordinates();

                int movesLeft = movePawn(originCoord, pressedHexCoord, selectedPawnId_);
                selectedPiece->setScale(0.4);
                selectedPawnId_ = -1;

                if(movesLeft != static_cast<int>(getCurrentPlayer()->getActionsLeft())){ // Movement happened
                    useActions(getCurrentPlayer()->getActionsLeft() - static_cast<unsigned int>(movesLeft));
                    getCurrentPlayer()->setActionsLeft(static_cast<unsigned int>(movesLeft));
                }
            }
        }

        if((selectedTransportId_ != -1) && (selectedTransport != nullptr)){ // Moving transport

            Common::CubeCoordinate originCoord = selectedTransport->getHex()->getCoordinates();
            int movesLeft = moveTransport(originCoord, pressedHexCoord, selectedTransportId_);

            if(movesLeft != static_cast<int>(getCurrentPlayer()->getActionsLeft())){ // Movement happened
                useActions(getCurrentPlayer()->getActionsLeft() - static_cast<unsigned int>(movesLeft));
                getCurrentPlayer()->setActionsLeft(static_cast<unsigned int>(movesLeft));
                selectedTransportId_ = -1;
            }

        }

        return;
    }

    if(currentGamePhase() == Common::SINKING){

        if(pressedHex->getPieceType() != "Water"){
            std::string actor = flipTile(pressedHexCoord);

            if(actor != ""){
                if((actor == "dolphin") || (actor == "boat") ){

                    gameBoard_->createTransport(actor, pressedHexCoord);
                }
                else{
                    gameBoard_->createActor(actor, pressedHexCoord);
                }

                gameState_->changeGamePhase(Common::SPINNING);
                gameBoard_->setHint("Choose a actor or transport.");
                selectedTransportId_ = -1;
                selectedActorId_ = -1;
            }

            else{
                gameBoard_->setHint("Beach hexes need to be sunk first!");
            }
        }
    }

    if(currentGamePhase() == Common::SPINNING){

        if((wheelResult_ != "") && ((selectedTransportId_ != -1) || (selectedActorId_ != -1))){

            if((selectedTransport != nullptr) && (selectedActor == nullptr)){

                Common::CubeCoordinate startingHex = selectedTransport->getHex()->getCoordinates();
                Common::CubeCoordinate targetHex = pressedHexCoord;

                int result = moveTransportWithSpinner(startingHex, targetHex, selectedTransportId_, wheelResult_);

                if(result != 0){
                    selectedPawnId_ = -1;
                    selectedActorId_ = -1;
                    selectedTransportId_ = -1;
                    wheelResult_ = "";
                    nextPlayer();
                    return;
                }
            }
            else if((selectedActor != nullptr) && (selectedTransport == nullptr)){

                Common::CubeCoordinate startingHex = selectedActor->getHex()->getCoordinates();
                Common::CubeCoordinate targetHex = pressedHexCoord;

                bool result = checkActorMovement(startingHex, targetHex, selectedActorId_, wheelResult_);

                if(result != false){
                    moveActor(startingHex, targetHex, selectedActorId_, wheelResult_);

                    selectedPawnId_ = -1;
                    selectedActorId_ = -1;
                    selectedTransportId_ = -1;
                    wheelResult_ = "";
                    nextPlayer();
                    return;
                }

            }
        }
    }

}

void GameRunner::transportPress(std::shared_ptr<Common::Transport> pressedTransport)
{
    std::shared_ptr<Common::Hex> transportHex = pressedTransport->getHex();
    Common::CubeCoordinate transportCoord = transportHex->getCoordinates();
    std::shared_ptr<GamePiece> selectedPiece = gameBoard_->getGamePiece(selectedPawnId_);

    if(currentGamePhase() == Common::MOVEMENT){

        if(selectedPawnId_ == -1){ // Selecting vessel
            selectedTransportId_ = pressedTransport->getId();
        }

        if((selectedPawnId_ != -1) && (selectedPiece != nullptr)){ // Selected piece -> vessel

             if(!(selectedPiece->getCoordinates() == transportCoord)){
                 gameBoard_->setHint("You can only board vessels in that hex.");

                 selectedPawnId_ = -1;
                 selectedPiece->setScale(0.4);

                 return;
             }

             else if((static_cast<int>(pressedTransport->getPawnsInTransport().size()) >= pressedTransport->getMaxCapacity())){
                 gameBoard_->setHint("That vessel is full.");

                 selectedPawnId_ = -1;
                 selectedPiece->setScale(0.4);

                 return;
             }

             else if(!(selectedPiece->isOnTransport())){ // Board the vessel

                 std::shared_ptr<GamePiece> pawn = gameBoard_->getGamePiece(selectedPawnId_);
                 std::shared_ptr<Common::Hex> hex = gameBoard_->getHex(pawn->getCoordinates());

                 pawn->boardTransport(pressedTransport->getId());
                 pawn->setScale(0.4);

                 hex->removePawn(pawn);
                 gameBoard_->cleanPawnPos(gameBoard_->getHexPiece(pawn->getCoordinates()));

                 pressedTransport->addPawn(pawn);
                 pressedTransport->move(hex);
                 hex->addTransport(pressedTransport);


                 selectedPawnId_ = -1;

                 unsigned int actionsLeft = getCurrentPlayer()->getActionsLeft() - 1;

                 if(actionsLeft > 0){
                     getCurrentPlayer()->setActionsLeft(actionsLeft);
                 }
                 else{
                     getCurrentPlayer()->setActionsLeft(actionsLeft);
                     gameState_->changeGamePhase(Common::SINKING);
                     selectedActorId_ = -1;
                     selectedTransportId_ = -1;
                     selectedActorId_ = -1;
                 }

                 updateHintText();
             }

             else{
                 gameBoard_->setHint("You're already on that vessel.");
                 selectedPiece->setScale(0.4);
                 selectedActorId_ = -1;
                 selectedPawnId_ = -1;
                 selectedTransportId_ = -1;
             }
         }

    }
    if(currentGamePhase() == Common::SINKING){

    }
    if(currentGamePhase() == Common::SPINNING){

        if(wheelResult_ == ""){

            if(pressedTransport->canMove(currentPlayer())){
                selectedTransportId_ = pressedTransport->getId();
                selectedActorId_ = -1;
                gameBoard_->setHint("Now spin the wheel.");
            }

            else{
                gameBoard_->setHint("You cant move that piece, not enough your pawns onboard.");
                selectedActorId_ = -1;
                selectedTransportId_ = -1;
            }
        }
    }
}

void GameRunner::actorPress(std::shared_ptr<Common::Actor> pressedActor)
{
    if(currentGamePhase() == Common::SPINNING){

        if(wheelResult_ == ""){   
            selectedActorId_ = pressedActor->getId();
            selectedTransportId_ = -1;
            gameBoard_->setHint("Now spin the wheel.");
        }
    }
}

void GameRunner::wheelPress(std::string movements)
{
    if((currentGamePhase() == Common::SPINNING) && ((selectedActorId_ != -1) || (selectedTransportId_ != -1))
            && (selectedActorId_ != selectedTransportId_)){

        wheelResult_ = movements;

        std::string message;
        if(wheelResult_ == "D"){
            message = "You can dive to any water hex.";
        }
        else{
            message = "You can move " + wheelResult_ + " hexes.";
        }
        gameBoard_->setHint(message);
    }
}

void GameRunner::nextPlayer()
{
    int nextPlayer = currentPlayer() + 1;

    if(nextPlayer > playerAmount()){

        nextPlayer = 1;
    }
    gameState_->changePlayerTurn(nextPlayer);
    getCurrentPlayer()->setActionsLeft(3);
    gameState_->changeGamePhase(Common::MOVEMENT);

    countPoints();
    updateScoreBoard();
    updateHintText();

    if(gameBoard_->isGameOver()){
        gameBoard_->finishGame();
    }
    selectedActorId_ = -1;
    selectedPawnId_ = -1;
    selectedTransportId_ = -1;
    wheelResult_ = "";
}

void GameRunner::countPoints()
{
    Common::CubeCoordinate origo = Common::CubeCoordinate(0,0,0);
    std::shared_ptr<HexPiece> origoHex = gameBoard_->getHexPiece(origo);
    std::vector<std::shared_ptr<Common::Pawn>> pawnsInOrigo = origoHex->getPawns();

    for(unsigned int i = 0; i <pawnsInOrigo.size(); ++i){
        int pawnId = pawnsInOrigo.at(i)->getId();
        int pawnOwnerId = pawnsInOrigo.at(i)->getPlayerId();
        for(unsigned int j = 0; j < players_.size(); ++j){
            int playerId = players_.at(j)->getPlayerId();
            if(pawnOwnerId == playerId){
                players_.at(j)->addPoint();
                gameBoard_->removePawn(pawnId);
            }
        }
    }
}

void GameRunner::useActions(unsigned int actions)
{
    unsigned int actionsLeft = getCurrentPlayer()->getActionsLeft() - actions;

    if(actionsLeft > 0){
        getCurrentPlayer()->setActionsLeft(actionsLeft);
    }
    else{

        getCurrentPlayer()->setActionsLeft(actionsLeft);
        gameState_->changeGamePhase(Common::SINKING);
    }
    updateScoreBoard();
    updateHintText();
}

void GameRunner::skipTurn()
{
    countPoints();
    updateScoreBoard();
    nextPlayer();
}

bool GameRunner::readyForWheel()
{
    if(((selectedTransportId_ != -1) || (selectedActorId_ != -1)) && wheelResult_ == ""){
        return true;
    }
    return false;
}

void GameRunner::updateHintText()
{

    std::string playerName;
    std::string gamePhaseStr = "";
    Common::GamePhase gamePhase = currentGamePhase();
    unsigned int actionsLeft = 0;

    for(unsigned int i = 0; i < players_.size(); ++i){
        if(currentPlayer() == players_.at(i)->getPlayerId()){
            playerName = players_.at(i)->getPlayerName();
            actionsLeft = players_.at(i)->getActionsLeft();
        }
    }
    if(gamePhase == 1){
        gamePhaseStr = "Moving";
    }
    else if(gamePhase == 2){
        gamePhaseStr = "Sinking";
    }
    else if(gamePhase == 3){
        gamePhaseStr = "Spinning";
    }


    std::string message = "Phase: " + gamePhaseStr + ", In turn: " + playerName +
            ", Actions left: " + std::to_string(actionsLeft);

    gameBoard_->setHint(message);
}

void GameRunner::updateScoreBoard()
{
    std::vector<std::string> message;
    for(unsigned int i = 0; i < players_.size(); ++i){
        std::string stats;
        std::string name = players_.at(i)->getPlayerName();
        std::string points = std::to_string(players_.at(i)->getPoints());
        stats = "Player: " + name + " has " + points + " points.";
        message.push_back(stats);
    }
    gameBoard_->setScoreBoard(message);
}
