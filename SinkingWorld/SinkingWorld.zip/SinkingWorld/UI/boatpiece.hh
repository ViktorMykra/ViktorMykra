#ifndef BOATPIECE_HH
#define BOATPIECE_HH

#include "transport.hh"
#include "gamepiece.hh"

#include <QGraphicsPixmapItem>
#include <vector>

/* Impelents a playable boatpiece on the gameboard.
 * Boat can carry 4 pawns around in water hexes.
 */

class GameRunner;
class GameBoard;

class BoatPiece : public QObject, public QGraphicsPixmapItem, public Common::Transport
{
    Q_OBJECT
    Q_PROPERTY(QPointF pos READ pos WRITE setPos)

public:
    BoatPiece(int id, std::shared_ptr<GameRunner> gameRunner, GameBoard* gameBoard);
    ~BoatPiece();

    void movementAnimation(QPointF target);

    std::string getTransportType();

    std::vector<std::shared_ptr<Common::Pawn>> getPawnsInTransport();

    void move(std::shared_ptr<Common::Hex> to);

    bool canMove(int playerId) const;

protected:
    void mousePressEvent(QGraphicsSceneMouseEvent *event);

private:
    std::shared_ptr<GameRunner> gameRunner_;
    GameBoard* gameBoard_;
    QPropertyAnimation* movementAnimation_;
    std::string transportType_ = "boat";

    Common::CubeCoordinate coord_;
};

#endif // BOATPIECE_HH
