#include "gamepiece.hh"
#include "gamerunner.hh"

GamePiece::GamePiece(int pawnId, int playerId,
                     Common::CubeCoordinate pawnCoord, std::shared_ptr<GameRunner> gameRunner):
    pieceId_(pawnId),
    ownerId_(playerId),
    pieceCoord_(pawnCoord),
    gameRunner_(gameRunner)
{
    this->setToolTip(QString("Pawn, get these to the center."));
    SCALE_ = 0.4;

    setId(pawnId, playerId);
    setCoordinates(pawnCoord);

    this->setShapeMode(QGraphicsPixmapItem::BoundingRectShape);
    this->setTransformOriginPoint(25,25);
    this->setPixmap(QPixmap(QString(":/images/buttonimages/gamepiece.png")));
    this->setZValue(0);
    this->setScale(SCALE_);

    movementAnimation_ = new QPropertyAnimation(this, "pos");

    setColor();
}

GamePiece::~GamePiece()
{
    delete colorEffect_;
    delete movementAnimation_;
}

void GamePiece::movementAnimation(QPointF target)
{

    movementAnimation_->setDuration(500);
    movementAnimation_->setStartValue(this->pos());
    movementAnimation_->setEndValue(target);
    movementAnimation_->start();
}

void GamePiece::boardTransport(int transportId)
{
    isOnTransport_ = true;
    this->setZValue(-3);
    transportId_ = transportId;
}

void GamePiece::unboardTransport()
{
    isOnTransport_ = false;
    this->setZValue(0);
    transportId_ = -1;
}

bool GamePiece::isOnTransport()
{
    return isOnTransport_;
}

int GamePiece::getTransportId()
{
    return transportId_;
}

void GamePiece::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    gameRunner_->gamePiecePress(shared_from_this());
    event->accept();
}

void GamePiece::setColor()
{
    colorEffect_ = new QGraphicsColorizeEffect();

    if(ownerId_ == 1){
        colorEffect_->setColor(Qt::red);
    }
    else if(ownerId_ == 2){
        colorEffect_->setColor(Qt::cyan);
    }
    else if(ownerId_ == 3){
        colorEffect_->setColor(Qt::magenta);
    }
    else{
        colorEffect_->setColor(Qt::black);
    }

    this->setGraphicsEffect(colorEffect_);
}
