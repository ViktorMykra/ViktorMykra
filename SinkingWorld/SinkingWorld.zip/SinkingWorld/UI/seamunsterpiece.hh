#ifndef SEAMUNSTERPIECE_HH
#define SEAMUNSTERPIECE_HH

#include "actor.hh"

#include <QObject>
#include <QGraphicsPixmapItem>
#include <QPropertyAnimation>

/* Impelents a playable seamunster on the gameboard.
 * seamunster eats everything.
 */


class GameRunner;
class GameBoard;

class SeamunsterPiece : public QObject, public QGraphicsPixmapItem, public Common::Actor
{
    Q_OBJECT
    Q_PROPERTY(QPointF pos READ pos WRITE setPos)

public:
    SeamunsterPiece(int id, std::shared_ptr<GameRunner> gameRunner, GameBoard* gameBoard);
    ~SeamunsterPiece()=default;

    void move(std::shared_ptr<Common::Hex> to );
    void doAction();
    std::string getActorType() const;
    int getId() const;
    void addHex(std::shared_ptr<Common::Hex> hex);
    std::shared_ptr<Common::Hex> getHex();

protected:
    void mousePressEvent(QGraphicsSceneMouseEvent *event);

private slots:
    void animationFinished();

private:
    int id_;
    std::shared_ptr<GameRunner> gameRunner_;
    GameBoard* gameBoard_;
    QPropertyAnimation* movementAnimation_;

    std::shared_ptr<Common::Hex> hex1_;

    void movementAnimation(QPointF target);

};


#endif // SEAMUNSTERPIECE_HH
