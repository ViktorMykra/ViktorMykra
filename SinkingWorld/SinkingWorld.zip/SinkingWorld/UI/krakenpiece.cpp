#include "krakenpiece.hh"

#include "gameboard.hh"
#include "gamerunner.hh"


KrakenPiece::KrakenPiece(int id, std::shared_ptr<GameRunner> gameRunner, GameBoard* gameBoard) :
    id_(id),
    gameRunner_(gameRunner),
    gameBoard_(gameBoard)
{
    this->setToolTip(QString("Kraken, destroys boats."));
    this->setPixmap(QPixmap(QString(":/images/buttonimages/kraken.png")));

    movementAnimation_ = new QPropertyAnimation(this, "pos");

    this->setTransformOriginPoint(25, 25);
    this->setZValue(-4);

    connect(movementAnimation_, SIGNAL(finished()), this, SLOT(animationFinished()));
}

void KrakenPiece::move(std::shared_ptr<Common::Hex> to)
{
    if(hex1_ != nullptr){
        hex1_->removeActor(shared_from_this());
    }

    QPointF target = gameBoard_->getHexXY(to->getCoordinates());
    qreal targetX = target.rx()-20;
    qreal targetY = target.ry()-25;
    movementAnimation(QPointF(targetX, targetY));
    to->addActor(shared_from_this());
    addHex(to);

}

void KrakenPiece::doAction()
{
    std::vector<std::shared_ptr<Common::Transport>> boats = getHex()->getTransports();

    for(unsigned int i = 0; i < boats.size(); ++i){
        std::shared_ptr<Common::Transport> transport = boats.at(i);

        if(transport->getTransportType() == "boat"){
            std::vector<std::shared_ptr<Common::Pawn>> pawnsOnBoat = transport->getPawnsInTransport();

            unsigned int freeSpotsOnHex = static_cast<unsigned int>(3 - (getHex()->getPawnAmount()));
            for(unsigned int j = 0; j < pawnsOnBoat.size(); ++j){
                if(j < freeSpotsOnHex){
                    std::shared_ptr<GamePiece> pawnOnBoat = gameBoard_->getGamePiece(pawnsOnBoat.at(j)->getId());

                    transport->removePawn(pawnsOnBoat.at(j));

                    pawnOnBoat->unboardTransport();

                    gameBoard_->movePawn(pawnsOnBoat.at(j)->getId(), getHex()->getCoordinates());
                }
            }



        }

        std::vector<std::shared_ptr<Common::Pawn>> pawnsStillOnBoat = transport->getPawnsInTransport();
        // If all pawns cant fit in to the hex, they will drown. Too bad.
        if(pawnsStillOnBoat.size()>0){
            transport->removePawns();
            for(unsigned int k = 0; k < pawnsStillOnBoat.size(); ++k){
                gameBoard_->removePawn(pawnsStillOnBoat.at(k)->getId());
            }
        }
        gameBoard_->removeTransport(transport->getId());
    }
}

std::string KrakenPiece::getActorType() const
{
    return "kraken";
}

int KrakenPiece::getId() const
{
    return id_;
}

void KrakenPiece::addHex(std::shared_ptr<Common::Hex> hex)
{
    hex1_ = hex;
}

std::shared_ptr<Common::Hex> KrakenPiece::getHex()
{
    return hex1_;
}

void KrakenPiece::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    event->accept();
    gameRunner_->actorPress(shared_from_this());
}

void KrakenPiece::animationFinished()
{
    doAction();
}

void KrakenPiece::movementAnimation(QPointF target)
{
    movementAnimation_->setDuration(450);
    movementAnimation_->setStartValue(this->pos());
    movementAnimation_->setEndValue(target);
    movementAnimation_->start();

}
