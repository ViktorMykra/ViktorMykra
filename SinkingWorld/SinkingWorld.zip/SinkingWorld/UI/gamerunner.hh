#ifndef GAMERUNNER_HH
#define GAMERUNNER_HH

#include "igamerunner.hh"
#include "player.hh"
#include "gamestate.hh"
#include "gamepiece.hh"
#include "hexpiece.hh"
#include "wheel.hh"
#include "actor.hh"

#include <string>
#include <vector>
#include <memory>

/* Impelents a runner for the game.
 * Handles clickevents on gameboard and logic behind gamerules.
 */


class GameBoard;
class GameRunner: public Common::IGameRunner
{
public:
    GameRunner(std::vector<std::shared_ptr<Player>> players, GameBoard* gameBoard);
    ~GameRunner()=default;

    // IGameRunner interface
public:
    int movePawn(Common::CubeCoordinate origin, Common::CubeCoordinate target, int pawnId);

    void moveActor(Common::CubeCoordinate origin, Common::CubeCoordinate target, int actorId, std::string moves);

    int moveTransport(Common::CubeCoordinate origin, Common::CubeCoordinate target, int transportId);

    int moveTransportWithSpinner(Common::CubeCoordinate origin, Common::CubeCoordinate target, int transportId, std::string moves);

    int checkPawnMovement(Common::CubeCoordinate origin, Common::CubeCoordinate target, int pawnId);

    bool checkActorMovement(Common::CubeCoordinate origin, Common::CubeCoordinate target, int actorId, std::string moves);

    int checkTransportMovement(Common::CubeCoordinate origin, Common::CubeCoordinate target, int transportId, std::string moves);

    std::string flipTile(Common::CubeCoordinate tileCoord);
    std::pair<std::string, std::string> spinWheel();
    Common::SpinnerLayout getSpinnerLayout() const;
    std::shared_ptr<Common::IPlayer> getCurrentPlayer();
    int currentPlayer() const;
    int playerAmount() const;
    Common::GamePhase currentGamePhase() const;

    int calculateDistance(Common::CubeCoordinate origin, Common::CubeCoordinate target);
    std::vector<Common::CubeCoordinate> getRouteHexes(Common::CubeCoordinate origin, Common::CubeCoordinate target);
    Common::CubeCoordinate cube_lerp(Common::CubeCoordinate origin, Common::CubeCoordinate target, double k);
    int lerp(int a, int b, double k);

    void gamePiecePress(std::shared_ptr<Common::Pawn> pressedPiece);
    void hexPress(std::shared_ptr<Common::Hex> pressedHex);
    void transportPress(std::shared_ptr<Common::Transport> pressedTransport);
    void actorPress(std::shared_ptr<Common::Actor> pressedActor);
    void wheelPress(std::string movements);

    void nextPlayer();
    void countPoints();
    void useActions(unsigned int actions);

    void skipTurn();
    bool readyForWheel();

    void updateHintText();
    void updateScoreBoard();

private:

    std::vector<std::shared_ptr<Player>> players_;
    GameBoard* gameBoard_;
    std::shared_ptr<GameState> gameState_;

    int selectedPawnId_ = -1;
    int selectedTransportId_ = -1;
    int selectedActorId_ = -1;
    std::string wheelResult_;

    unsigned int playerCount_;


};

#endif // GAMERUNNER_HH
