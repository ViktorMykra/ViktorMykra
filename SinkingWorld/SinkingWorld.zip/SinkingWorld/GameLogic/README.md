# GameLogic

This project serves as the game engine for IslandGame project. 

This README is not comprehensive, and is subject to change.

### Getting started

Copy the asset file examples in Assets folder to correct names.

For example

`cp Assets/pieces.json_example Assets/pieces.json`